#!/usr/bin/env bash
# Isolate the recovery benchmark preflight failure on one non-flagged A100 node.
#SBATCH --job-name=gpuprobe24
#SBATCH --partition=gpu
#SBATCH --gres=gpu:a100:1
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=2
#SBATCH --mem=8G
#SBATCH --time=00:10:00
#SBATCH --exclude=n2gpu1204,n2gpu1208,n2gpu1211,n2gpu1213,n2gpu1219,n2gpu1222,n2gpu1226,n2gpu1228,n2gpu1229,n2gpu1231
#SBATCH --output=/scratch/hpc-prf-merlin/joel/moe-study/outputs/pipeline_runs/gpu_preflight_probe_20260724.%j.log

set -o pipefail
module purge
module load toolchain/foss/2024a system/CUDA/12.6.0
source /opt/software/pc2/EB-SW/software/Miniforge3/24.1.2-0/etc/profile.d/conda.sh
conda activate merlin
cd /scratch/hpc-prf-merlin/joel/moe-study

failed=0
probe() {
  echo "[PROBE_START] $*"
  timeout --signal=TERM --kill-after=10 60s "$@"
  rc=$?
  echo "[PROBE_END] rc=${rc} $*"
  if [[ "$rc" -ne 0 ]]; then failed=1; fi
}

probe nvidia-smi -L
probe nvidia-smi --query-gpu=index,name,uuid,ecc.errors.uncorrected.volatile.total --format=csv,noheader,nounits
probe python -c 'import torch; print(torch.cuda.device_count()); print(torch.cuda.get_device_name(0))'
exit "$failed"

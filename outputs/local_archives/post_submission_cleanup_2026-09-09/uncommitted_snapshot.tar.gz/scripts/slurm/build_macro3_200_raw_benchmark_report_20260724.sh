#!/usr/bin/env bash
#SBATCH --job-name=r24_m3_200_raw_report
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=2
#SBATCH --mem=16G
#SBATCH --time=01:00:00
#SBATCH --output=/scratch/hpc-prf-merlin/joel/moe-study/outputs/pipeline_runs/moe_study_final_v1_v2_recovery_20260724/logs/macro3_200_raw_report.%j.log

set -euo pipefail
ROOT=/scratch/hpc-prf-merlin/joel/moe-study
export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"
cd "$ROOT"
exec /scratch/hpc-prf-merlin/joel/conda/envs/merlin/bin/python scripts/analysis/build_macro3_200_raw_benchmark_report.py

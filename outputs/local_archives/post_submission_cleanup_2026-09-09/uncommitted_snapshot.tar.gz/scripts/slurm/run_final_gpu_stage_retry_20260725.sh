#!/usr/bin/env bash
# `PROFILE`, `RUN_ID`, and `STAGE` are supplied through sbatch --export.
#SBATCH --partition=gpu
#SBATCH --gres=gpu:a100:1
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=16
#SBATCH --mem=128G
#SBATCH --time=24:00:00

set -eo pipefail
: "${PROFILE:?PROFILE is required}"
: "${RUN_ID:?RUN_ID is required}"
: "${STAGE:?STAGE is required}"

case "$STAGE" in
  final_eval_loss|benchmark) ;;
  *) echo "Unsupported stage: $STAGE" >&2; exit 2 ;;
esac

module purge
module load toolchain/foss/2024a system/CUDA/12.6.0
source /opt/software/pc2/EB-SW/software/Miniforge3/24.1.2-0/etc/profile.d/conda.sh
conda activate merlin
cd /scratch/hpc-prf-merlin/joel/moe-study

export HF_HOME=/scratch/hpc-prf-merlin/shared_cache/huggingface
export HF_DATASETS_CACHE=/scratch/hpc-prf-merlin/shared_cache/huggingface/datasets
export PYTHONPATH="$PWD:$PWD/LLaMA-Factory/src:${PYTHONPATH:-}"
export WANDB_MODE=disabled

echo "[GPU_PREFLIGHT] profile=${PROFILE} run=${RUN_ID} stage=${STAGE}"
timeout --signal=TERM --kill-after=30 330s python -u -m pipeline.gpu_preflight \
  --required-gpu-count 1 --required-gpu-name A100 --timeout-seconds 300 --check-ecc
echo "[GPU_PREFLIGHT_OK]"

exec python -u -m pipeline.run --config configs/pipeline --profile "$PROFILE" \
  --start-at "$STAGE" --stop-after "$STAGE" --force-stage "$STAGE" \
  --executor-type local --run-id "$RUN_ID"

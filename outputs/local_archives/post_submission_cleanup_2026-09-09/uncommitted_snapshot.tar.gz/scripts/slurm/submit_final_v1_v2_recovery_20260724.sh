#!/usr/bin/env bash
# Submit the recovery DAG from a normal Slurm node, avoiding login-node shared
# filesystem stalls.  The Python submission script fails closed if its manifest
# already exists, so this is safe against an earlier interrupted invocation.
#SBATCH --job-name=submitr24
#SBATCH --partition=normal
#SBATCH --cpus-per-task=8
#SBATCH --mem=32G
#SBATCH --time=01:00:00
#SBATCH --output=/scratch/hpc-prf-merlin/joel/moe-study/outputs/pipeline_runs/moe_study_final_v1_v2_recovery_20260724/submitter.%j.log

set -eo pipefail
module purge
module load toolchain/foss/2024a
source /opt/software/pc2/EB-SW/software/Miniforge3/24.1.2-0/etc/profile.d/conda.sh
conda activate merlin
cd /scratch/hpc-prf-merlin/joel/moe-study
python -u scripts/analysis/recover_final_v1_v2_study.py --submit

#!/bin/bash
set -euo pipefail

module purge
module load toolchain/foss/2024a system/CUDA/12.6.0

PYTHON=/scratch/hpc-prf-merlin/joel/conda/envs/merlin/bin/python
cd /scratch/hpc-prf-merlin/joel/moe-study

"${PYTHON}" -m pipeline.gpu_preflight \
  --required-gpu-count 1 \
  --required-gpu-name A100 \
  --check-ecc \
  --timeout-seconds 120

"${PYTHON}" - <<'PY'
import torch

torch.manual_seed(42)
device = torch.device("cuda:0")
x = torch.randn((8192, 8192), device=device, dtype=torch.bfloat16)
y = torch.randn((8192, 8192), device=device, dtype=torch.bfloat16)
for _ in range(20):
    z = x @ y
    x, y = y, z.mul_(1e-3)
torch.cuda.synchronize()
checksum = float(z.float().mean().item())
if not torch.isfinite(z).all().item():
    raise SystemExit("GPU compute probe produced non-finite values")
print(f"[GPU_COMPUTE_PROBE_OK] node_checksum={checksum:.8g}", flush=True)
PY

"${PYTHON}" -m pipeline.gpu_preflight \
  --required-gpu-count 1 \
  --required-gpu-name A100 \
  --check-ecc \
  --timeout-seconds 120

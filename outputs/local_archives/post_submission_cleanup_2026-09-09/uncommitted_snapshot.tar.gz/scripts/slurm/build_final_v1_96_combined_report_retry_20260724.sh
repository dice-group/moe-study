#!/usr/bin/env bash
#SBATCH --job-name=r24_combined_v1_96_retry
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=2
#SBATCH --mem=16G
#SBATCH --time=01:00:00
#SBATCH --output=/scratch/hpc-prf-merlin/joel/moe-study/outputs/pipeline_runs/moe_study_final_v1_v2_recovery_20260724/logs/combined_v1_96_report_retry.%j.log

set -euo pipefail

ROOT=/scratch/hpc-prf-merlin/joel/moe-study
export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"
cd "$ROOT"

/scratch/hpc-prf-merlin/joel/conda/envs/merlin/bin/python - <<'PY'
import importlib.util
from pathlib import Path

from pipeline_tools.reporting import artifacts
from pipeline_tools.reporting.workbook import build_workbook

# The report script was created with the builder imported from the wrong module.
# Supply the same builder before loading it; no experiment data are altered.
artifacts.build_workbook = build_workbook

path = Path("scripts/analysis/build_final_v1_96_combined_report.py")
spec = importlib.util.spec_from_file_location("combined_report", path)
module = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(module)
module.OUT = Path("outputs/pipeline_runs/moe_study_final_v1_96_combined_report_20260724_slurm").resolve()
module.main()
PY

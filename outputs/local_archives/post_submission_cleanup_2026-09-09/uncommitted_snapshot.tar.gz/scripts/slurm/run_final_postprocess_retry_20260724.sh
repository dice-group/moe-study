#!/usr/bin/env bash
# `PROFILE` and `STAGE` (summary or report) are supplied through sbatch --export.
#SBATCH --partition=normal
#SBATCH --cpus-per-task=8
#SBATCH --mem=64G
#SBATCH --time=04:00:00

set -eo pipefail
: "${PROFILE:?PROFILE is required}"
: "${STAGE:?STAGE is required}"
module purge
module load toolchain/foss/2024a
source /opt/software/pc2/EB-SW/software/Miniforge3/24.1.2-0/etc/profile.d/conda.sh
conda activate merlin
cd /scratch/hpc-prf-merlin/joel/moe-study
export HF_HOME=/scratch/hpc-prf-merlin/shared_cache/huggingface
export HF_DATASETS_CACHE=/scratch/hpc-prf-merlin/shared_cache/huggingface/datasets
export PYTHONPATH="$PWD:$PWD/LLaMA-Factory/src:${PYTHONPATH:-}"
export WANDB_MODE=disabled

args=(python -u -m pipeline.run --config configs/pipeline --profile "$PROFILE"
  --start-at "$STAGE" --stop-after "$STAGE" --force-stage "$STAGE"
  --executor-type local)
if [[ -n "${RUN_IDS:-}" ]]; then
  normalized_run_ids="${RUN_IDS//,/ }"
  normalized_run_ids="${normalized_run_ids//+/ }"
  read -ra selected <<< "$normalized_run_ids"
  for run_id in "${selected[@]}"; do
    args+=(--run-id "$run_id")
  done
fi
exec "${args[@]}"

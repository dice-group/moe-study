#!/bin/bash
#SBATCH --job-name=v2panelcheck
#SBATCH --partition=normal
#SBATCH --cpus-per-task=8
#SBATCH --mem=64G
#SBATCH --time=04:00:00
#SBATCH --output=/scratch/hpc-prf-merlin/joel/moe-study/outputs/pipeline_runs/v2_panel_preflight_20260724.%j.log

set -eo pipefail
module purge
module load toolchain/foss/2024a
source /opt/software/pc2/EB-SW/software/Miniforge3/24.1.2-0/etc/profile.d/conda.sh
conda activate merlin
cd /scratch/hpc-prf-merlin/joel/moe-study
# Fail closed on the frozen task contract before scheduling the actual
# end-to-end evaluation.  Loading one document for every task here is
# needlessly I/O-heavy; the submitted benchmark jobs themselves exercise all
# task datasets.
python -u scripts/analysis/validate_final_v2_benchmark_panel.py --panels 96,200

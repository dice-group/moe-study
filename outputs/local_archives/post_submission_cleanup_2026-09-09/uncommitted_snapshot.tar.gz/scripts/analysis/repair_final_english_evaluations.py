#!/usr/bin/env python3
"""Replace failed English eval jobs and rebuild their downstream DAG."""

from __future__ import annotations

import json
import os
import re
import subprocess
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[2]
OUTPUT = ROOT / "outputs/pipeline_runs/moe_study_final_english_eval_20260725"
MANIFEST = OUTPUT / "submission_manifest.json"
TASKS_FILE = ROOT / "configs/benchmark_panels/english/final_english_tasks.txt"
BAD_GPU_NODES = "n2gpu1212,n2gpu1217,n2gpu1223,n2gpu1227"
BAD_CPU_NODES = "n2cn1086"


def submit_job(args: list[str]) -> str:
    result = subprocess.run(
        ["sbatch", "--parsable", *args],
        cwd=ROOT,
        check=True,
        capture_output=True,
        text=True,
    )
    job_id = result.stdout.strip().split(";", 1)[0]
    if not re.fullmatch(r"\d+", job_id):
        raise ValueError(f"Unexpected sbatch output: {result.stdout!r}")
    return job_id


def save(payload: dict[str, Any]) -> None:
    temporary = MANIFEST.with_name(f".{MANIFEST.name}.tmp.{os.getpid()}")
    temporary.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, MANIFEST)


def main() -> None:
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    jobs = manifest["jobs"]
    failed_ids = {
        "33775716", "33775717", "33775718", "33775719", "33775720",
        "33775721", "33775722", "33775723", "33775724", "33775725",
    }
    failed = [job for job in jobs if job["job_id"] in failed_ids]
    if {job["job_id"] for job in failed} != failed_ids:
        raise ValueError("Could not resolve all failed original adapter jobs from the manifest")

    obsolete = [
        job for job in jobs
        if job["stage"] in {"consolidate", "report", "validate_workbooks"}
        and not job.get("superseded")
    ]
    subprocess.run(["scancel", *[job["job_id"] for job in obsolete]], check=True)
    for job in obsolete:
        job["superseded"] = True
    save(manifest)

    logs = OUTPUT / "logs"
    replacements: list[str] = []
    for old in failed:
        if old.get("superseded_by"):
            old["superseded"] = True
            replacements.append(str(old["superseded_by"]))
            continue
        size = str(old["size"])
        run_id = str(old["run_id"])
        job_id = submit_job(
            [
                f"--job-name=eng{size}_{run_id[:16]}_r1",
                f"--exclude={BAD_GPU_NODES}",
                f"--output={logs}/english_{size}_{run_id}.retry1.%j.log",
                (
                    "--export=ALL,"
                    f"RUN_ID={run_id},CHECKPOINT={old['checkpoint']},"
                    f"TASKS_FILE={TASKS_FILE.resolve()},OUTPUT_DIR={old['output_dir']}"
                ),
                "scripts/slurm/run_final_english_checkpoint_20260725.sh",
            ]
        )
        replacements.append(job_id)
        jobs.append(
            {
                **{key: value for key, value in old.items() if key != "job_id"},
                "job_id": job_id,
                "supersedes": old["job_id"],
                "retry": 1,
            }
        )
        old["superseded_by"] = job_id
        old["superseded"] = True
        save(manifest)

    dependency_inputs = [
        job["job_id"]
        for job in jobs
        if job["stage"] in {"adapter_evaluation", "baseline_evaluation"}
        and not job.get("superseded")
        and not job.get("superseded_by")
    ]
    consolidate = submit_job(
        [
            "--job-name=eng_consolidate_r1",
            f"--exclude={BAD_CPU_NODES}",
            f"--dependency=afterok:{':'.join(dependency_inputs)}",
            f"--output={logs}/english_consolidate.retry1.%j.log",
            "scripts/slurm/consolidate_final_english_evaluations.sh",
        ]
    )
    jobs.append(
        {
            "job_id": consolidate,
            "stage": "consolidate",
            "retry": 1,
            "dependency": f"afterok:{':'.join(dependency_inputs)}",
        }
    )
    save(manifest)

    reports: list[str] = []
    for panel in ("v1_96", "v1_200", "v2_96", "v2_200"):
        job_id = submit_job(
            [
                f"--job-name=eng_report_{panel}_r1",
                f"--exclude={BAD_CPU_NODES}",
                f"--dependency=afterok:{consolidate}",
                f"--output={logs}/english_report_{panel}.retry1.%j.log",
                f"--export=ALL,PANEL={panel},GROUPS=",
                "scripts/slurm/build_final_combined_top5_report.sh",
            ]
        )
        reports.append(job_id)
        jobs.append(
            {
                "job_id": job_id,
                "stage": "report",
                "panel": panel,
                "retry": 1,
                "dependency": f"afterok:{consolidate}",
            }
        )
        save(manifest)

    validation = submit_job(
        [
            "--job-name=eng_validate_r1",
            f"--exclude={BAD_CPU_NODES}",
            f"--dependency=afterok:{':'.join(reports)}",
            f"--output={logs}/english_validate.retry1.%j.log",
            "scripts/slurm/validate_final_english_workbooks.sh",
        ]
    )
    jobs.append(
        {
            "job_id": validation,
            "stage": "validate_workbooks",
            "retry": 1,
            "dependency": f"afterok:{':'.join(reports)}",
        }
    )
    manifest["terminal_job_id"] = validation
    save(manifest)
    print(
        json.dumps(
            {
                "replacement_jobs": replacements,
                "consolidate_job": consolidate,
                "report_jobs": reports,
                "terminal_job_id": validation,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Submit and audit the clean v1/v2 final-study recovery DAG.

This intentionally never overwrites a previous job graph.  Completed artifacts
remain the evidence for their original attempt; every replacement is recorded
in the recovery manifest under its own timestamp.
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from pipeline.config_loader import load_pipeline_config
from pipeline.run import _resolve_stage_cfg
from pipeline.runtime import _compute_pipeline_code_signature, _resolve_profile, build_executor


RECOVERY_ROOT = ROOT / "outputs/pipeline_runs/moe_study_final_v1_v2_recovery_20260724"
MANIFEST = RECOVERY_ROOT / "submission_manifest.json"
V2_PANEL_VALIDATOR = ROOT / "scripts/analysis/validate_final_v2_benchmark_panel.py"

# These are terminal or stale dependencies from the failed v2 alias attempt,
# the original MTL overflow, and obsolete CoLA follow-ups.  The active training
# jobs and their acceptance jobs are deliberately absent from this list.
STALE_JOB_IDS = (
    "33689569", "33689575", "33689614", "33689615",
    "33743812", "33743813", "33743814", "33743815",
    "33743822", "33743824", "33743826", "33743827", "33743828", "33743830",
    "33743832", "33743833", "33743834", "33743835",
    "33744756", "33744757", "33744765", "33744766",
    "33744806", "33744810", "33744812", "33744814", "33744816", "33744819",
    "33744823", "33744862", "33744863", "33744877", "33744878",
)

ACTIVE_ACCEPTANCE = {
    "macro45_200_moelora": "33703598",
    "macro45_200_mola": "33703599",
    "mtllora5e5_200": "33711249",
}


def _stage_command(profile: str, stage: str, run_id: str | None = None) -> list[str]:
    command = [
        sys.executable,
        "-m",
        "pipeline.run",
        "--config",
        "configs/pipeline",
        "--profile",
        profile,
        "--start-at",
        stage,
        "--stop-after",
        stage,
        "--force-stage",
        stage,
        "--executor-type",
        "local",
    ]
    if run_id:
        command.extend(["--run-id", run_id])
    return command


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp.{os.getpid()}")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def _base_env(timestamp: str) -> dict[str, str]:
    env = dict(os.environ)
    env.update(
        {
            "HF_HOME": "/scratch/hpc-prf-merlin/shared_cache/huggingface",
            "HF_DATASETS_CACHE": "/scratch/hpc-prf-merlin/shared_cache/huggingface/datasets",
            "PROOF_PIPELINE_CODE_SIG": _compute_pipeline_code_signature(ROOT),
            "PROOF_PIPELINE_REPO_ROOT": str(ROOT),
            "PROOF_PIPELINE_RUN_TIMESTAMP": timestamp,
            "PYTHONPATH": f"{ROOT}:{ROOT / 'LLaMA-Factory/src'}:{env.get('PYTHONPATH', '')}",
            "WANDB_MODE": "disabled",
        }
    )
    return env


def _validate_profiles(config: dict[str, Any]) -> None:
    names = {
        "moe_study_final_macro3_200_final_eval_recovery_20260724",
        "moe_study_final_macro45_200_recovery_20260724",
        "moe_study_final_mtllora_lr5e5_200_recovery_20260724",
        "moe_study_final_macro45_96_report_recovery_20260724",
        "moe_study_final_macro3_96_langs_benchmark_v2_recovery_20260724",
        "moe_study_final_macro3_200_langs_benchmark_v2_recovery_20260724",
        "moe_study_final_macro45_96_langs_benchmark_v2_recovery_20260724",
        "moe_study_final_macro45_200_langs_benchmark_v2_recovery_20260724",
        "moe_study_final_mtllora_lr5e5_96_langs_benchmark_v2_recovery_20260724",
        "moe_study_final_mtllora_lr5e5_200_langs_benchmark_v2_recovery_20260724",
    }
    for name in names:
        profile = _resolve_profile(config, name)
        if not isinstance(profile, dict):
            raise SystemExit(f"Cannot resolve recovery profile: {name}")
    for name in (
        "moe_study_final_macro3_200_final_eval_recovery_20260724",
        "moe_study_final_macro45_200_recovery_20260724",
        "moe_study_final_mtllora_lr5e5_200_recovery_20260724",
    ):
        profile = _resolve_profile(config, name)
        if profile["stage_executors"]["final_eval_loss"]["time"] != "24:00:00":
            raise SystemExit(f"{name}: final evaluation must have a 24-hour limit")


def _cancel_stale() -> None:
    state = subprocess.run(
        ["squeue", "-h", "-j", ",".join(STALE_JOB_IDS), "-o", "%i|%T|%R"],
        check=True,
        capture_output=True,
        text=True,
    )
    active = [line.split("|", 1)[0] for line in state.stdout.splitlines() if line.strip()]
    if active:
        subprocess.run(["scancel", *active], check=True)
        print(f"Cancelled stale pending jobs: {', '.join(active)}")
    else:
        print("No stale jobs remain in the queue")


def _submit_job(
    *,
    config: dict[str, Any],
    profile_name: str,
    stage: str,
    run_id: str | None,
    dependency: str | None,
    timestamp: str,
    env: dict[str, str],
    jobs: list[dict[str, Any]],
) -> str:
    profile = _resolve_profile(config, profile_name)
    executor = build_executor(profile, _resolve_stage_cfg(profile, stage))
    log_dir = RECOVERY_ROOT / "logs" / "chain"
    script = log_dir / "sbatch" / f"{stage}.{run_id or 'all'}.{timestamp}.sbatch.sh"
    log = log_dir / "logs" / f"{stage}.{run_id or 'all'}.{timestamp}.log"
    slurm_output = log_dir / "slurm" / f"{stage}.{run_id or 'all'}.{timestamp}.slurm.log"
    for path in (script.parent, log.parent, slurm_output.parent):
        path.mkdir(parents=True, exist_ok=True)
    job_id = executor.submit(
        _stage_command(profile_name, stage, run_id),
        dict(env),
        False,
        log,
        dependency=dependency,
        job_name=f"r24_{stage}_{run_id or 'all'}",
        script_path=script,
        slurm_output=slurm_output,
    )
    if not job_id or not str(job_id).isdigit():
        raise SystemExit(f"Submission failed: profile={profile_name} stage={stage} run={run_id}")
    jobs.append(
        {
            "profile": profile_name,
            "stage": stage,
            "run_id": run_id,
            "job_id": str(job_id),
            "dependency": dependency,
            "script_path": str(script),
            "log_path": str(log),
            "slurm_output": str(slurm_output),
        }
    )
    return str(job_id)


def _submit_group(
    *,
    config: dict[str, Any],
    profile: str,
    run_dependencies: dict[str, str | None],
    include_final_eval: bool,
    include_postprocess: bool,
    timestamp: str,
    env: dict[str, str],
    jobs: list[dict[str, Any]],
) -> None:
    benchmark_jobs: list[str] = []
    final_eval_jobs: list[str] = []
    for run_id, dependency in run_dependencies.items():
        if include_final_eval:
            final_eval_jobs.append(
                _submit_job(
                    config=config, profile_name=profile, stage="final_eval_loss", run_id=run_id,
                    dependency=dependency, timestamp=timestamp, env=env, jobs=jobs,
                )
            )
        benchmark_jobs.append(
            _submit_job(
                config=config, profile_name=profile, stage="benchmark", run_id=run_id,
                dependency=dependency, timestamp=timestamp, env=env, jobs=jobs,
            )
        )
    if include_postprocess:
        summary_dependency = "afterok:" + ":".join([*final_eval_jobs, *benchmark_jobs])
        summary_job = _submit_job(
            config=config, profile_name=profile, stage="summary", run_id=None,
            dependency=summary_dependency, timestamp=timestamp, env=env, jobs=jobs,
        )
        _submit_job(
            config=config, profile_name=profile, stage="report", run_id=None,
            dependency=f"afterok:{summary_job}", timestamp=timestamp, env=env, jobs=jobs,
        )


def submit() -> None:
    if MANIFEST.exists():
        raise SystemExit(f"Recovery manifest already exists: {MANIFEST}")
    config = load_pipeline_config(ROOT / "configs/pipeline")
    _validate_profiles(config)
    timestamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d_%H%M%S")
    env = _base_env(timestamp)
    jobs: list[dict[str, Any]] = []
    manifest: dict[str, Any] = {
        "schema_version": 1,
        "created_utc": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
        "purpose": "clean v1/v2 final-study recovery after v2 Belebele alias failure",
        "code_signature": env["PROOF_PIPELINE_CODE_SIG"],
        "stale_job_ids": list(STALE_JOB_IDS),
        "active_training_acceptance_dependencies": ACTIVE_ACCEPTANCE,
        "terminal_run_status": [
            {
                "run_id": "mtllora_r8_nup16",
                "campaigns": ["v1_macro3_96", "v1_macro3_200", "v2_macro3_96", "v2_macro3_200"],
                "status": "diverged",
                "reason": "lm-eval weighted perplexity overflow after pathological FLORES likelihoods",
                "replacement_run_id": "mtllora_lr5e5_r8_nup16",
            }
        ],
        "jobs": jobs,
    }
    _write_json(MANIFEST, manifest)

    # Existing completed macro-3 checkpoints: only their previously timed-out
    # final-loss stage must be repaired.  Original MTL is intentionally absent.
    for run_id in ("moelora_tr32_e16_k8", "hydralora_r2"):
        _submit_job(
            config=config, profile_name="moe_study_final_macro3_200_final_eval_recovery_20260724",
            stage="final_eval_loss", run_id=run_id, dependency=None,
            timestamp=timestamp, env=env, jobs=jobs,
        )

    # The prior macro45 report timed out on a normal node after the summary was
    # already complete; retry only report with the expanded limit.
    _submit_job(
        config=config, profile_name="moe_study_final_macro45_96_report_recovery_20260724",
        stage="report", run_id=None, dependency=None, timestamp=timestamp, env=env, jobs=jobs,
    )

    _submit_group(
        config=config, profile="moe_study_final_macro45_200_recovery_20260724",
        run_dependencies={
            "moelora_tr64_e32_k8": f"afterok:{ACTIVE_ACCEPTANCE['macro45_200_moelora']}",
            "mola_tr16_e8_k6": f"afterok:{ACTIVE_ACCEPTANCE['macro45_200_mola']}",
        },
        include_final_eval=True, include_postprocess=True, timestamp=timestamp, env=env, jobs=jobs,
    )
    _submit_group(
        config=config, profile="moe_study_final_mtllora_lr5e5_200_recovery_20260724",
        run_dependencies={"mtllora_lr5e5_r8_nup16": f"afterok:{ACTIVE_ACCEPTANCE['mtllora5e5_200']}"},
        include_final_eval=True, include_postprocess=True, timestamp=timestamp, env=env, jobs=jobs,
    )

    # v2 is a fresh, full panel.  The diverged original MTL remains a declared
    # terminal status; only benchmarkable runs are submitted.
    v2_groups = (
        ("moe_study_final_macro3_96_langs_benchmark_v2_recovery_20260724", {"moelora_tr32_e16_k8": None, "hydralora_r2": None}),
        ("moe_study_final_macro3_200_langs_benchmark_v2_recovery_20260724", {"moelora_tr32_e16_k8": None, "hydralora_r2": None}),
        ("moe_study_final_macro45_96_langs_benchmark_v2_recovery_20260724", {"moelora_tr64_e32_k8": None, "mola_tr16_e8_k6": None}),
        ("moe_study_final_macro45_200_langs_benchmark_v2_recovery_20260724", {
            "moelora_tr64_e32_k8": f"afterok:{ACTIVE_ACCEPTANCE['macro45_200_moelora']}",
            "mola_tr16_e8_k6": f"afterok:{ACTIVE_ACCEPTANCE['macro45_200_mola']}",
        }),
        ("moe_study_final_mtllora_lr5e5_96_langs_benchmark_v2_recovery_20260724", {"mtllora_lr5e5_r8_nup16": None}),
        ("moe_study_final_mtllora_lr5e5_200_langs_benchmark_v2_recovery_20260724", {"mtllora_lr5e5_r8_nup16": f"afterok:{ACTIVE_ACCEPTANCE['mtllora5e5_200']}"}),
    )
    for profile, dependencies in v2_groups:
        _submit_group(
            config=config, profile=profile, run_dependencies=dependencies,
            include_final_eval=False, include_postprocess=True,
            timestamp=timestamp, env=env, jobs=jobs,
        )
    _write_json(MANIFEST, manifest)
    print(f"Submitted {len(jobs)} recovery jobs; manifest={MANIFEST}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--validate-only", action="store_true")
    parser.add_argument("--cancel-stale", action="store_true")
    parser.add_argument("--submit", action="store_true")
    args = parser.parse_args()
    if not any((args.validate_only, args.cancel_stale, args.submit)):
        parser.error("one of --validate-only, --cancel-stale, or --submit is required")

    config = load_pipeline_config(ROOT / "configs/pipeline")
    _validate_profiles(config)
    validator = subprocess.run([sys.executable, str(V2_PANEL_VALIDATOR), "--panels", "96,200"], cwd=ROOT)
    if validator.returncode:
        return validator.returncode
    if args.validate_only:
        print("PASS: recovery profiles and static v2 panel contract are valid")
    if args.cancel_stale:
        _cancel_stale()
    if args.submit:
        submit()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

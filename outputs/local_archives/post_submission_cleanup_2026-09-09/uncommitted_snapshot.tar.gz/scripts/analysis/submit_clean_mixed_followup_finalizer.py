#!/usr/bin/env python3
"""Submit fail-closed consolidation after all effective repaired evaluations finish."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
from pathlib import Path
from typing import Any


REPO_ROOT = Path(__file__).resolve().parents[2]
EVALUATION_GRAPH_V13 = REPO_ROOT / (
    "outputs/pipeline_runs/moe_study_mixed_rank_expert_followup_clean22_evaluation_repair_v13/"
    "logs/chain/evaluation_job_graph.json"
)
ROUTED_FINAL_EVAL_REPAIR_GRAPH_V14 = REPO_ROOT / (
    "outputs/pipeline_runs/moe_study_mixed_rank_expert_followup_clean22_routed_final_eval_repair_v14/"
    "logs/chain/job_graph.json"
)
OUTPUT_ROOT = REPO_ROOT / "outputs/pipeline_runs/moe_study_mixed_rank_expert_followup_clean22_consolidated_v13"
MANIFEST = OUTPUT_ROOT / "finalizer_submission.json"


def _read(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"{path} is not a JSON object")
    return payload


def _write(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp.{os.getpid()}")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--validate-only", action="store_true")
    args = parser.parse_args()
    if MANIFEST.exists():
        raise SystemExit(f"finalizer was already submitted: {MANIFEST}")

    graph_v13 = _read(EVALUATION_GRAPH_V13)
    jobs_v13 = graph_v13.get("jobs", [])
    if not isinstance(jobs_v13, list) or len(jobs_v13) != 44:
        raise SystemExit(f"{EVALUATION_GRAPH_V13}: expected 44 job records")

    repair_graph_v14 = _read(ROUTED_FINAL_EVAL_REPAIR_GRAPH_V14)
    preserved_jobs = repair_graph_v14.get("preserved_v13_jobs", [])
    replacement_jobs = repair_graph_v14.get("jobs", [])
    invalid_jobs = repair_graph_v14.get("invalid_v13_final_eval_jobs", [])
    if not isinstance(preserved_jobs, list) or len(preserved_jobs) != 28:
        raise SystemExit(f"{ROUTED_FINAL_EVAL_REPAIR_GRAPH_V14}: expected 28 preserved jobs")
    if not isinstance(replacement_jobs, list) or len(replacement_jobs) != 16:
        raise SystemExit(f"{ROUTED_FINAL_EVAL_REPAIR_GRAPH_V14}: expected 16 replacement jobs")
    if not isinstance(invalid_jobs, list) or len(invalid_jobs) != 16:
        raise SystemExit(f"{ROUTED_FINAL_EVAL_REPAIR_GRAPH_V14}: expected 16 invalid v13 jobs")

    v13_ids = {str(job.get("job_id", "")) for job in jobs_v13 if isinstance(job, dict)}
    preserved_ids = {str(job.get("job_id", "")) for job in preserved_jobs if isinstance(job, dict)}
    invalid_ids = {str(job.get("job_id", "")) for job in invalid_jobs if isinstance(job, dict)}
    if preserved_ids & invalid_ids or preserved_ids | invalid_ids != v13_ids:
        raise SystemExit("preserved and invalid job sets do not partition the v13 evaluation graph")

    effective_jobs = preserved_jobs + replacement_jobs
    effective_pairs = [
        (str(job.get("stage", "")), str(job.get("run_id", "")))
        for job in effective_jobs
        if isinstance(job, dict)
    ]
    if len(effective_pairs) != 44 or len(set(effective_pairs)) != 44:
        raise SystemExit("expected 44 unique effective stage/run pairs")
    for stage in ("final_eval_loss", "benchmark"):
        if sum(pair[0] == stage for pair in effective_pairs) != 22:
            raise SystemExit(f"effective graph must contain 22 {stage} jobs")

    dependency_jobs = [str(job.get("job_id", "")) for job in effective_jobs if isinstance(job, dict)]

    if len(dependency_jobs) != 44 or len(set(dependency_jobs)) != 44 or not all(job.isdigit() for job in dependency_jobs):
        raise SystemExit(f"expected 44 unique numeric downstream job IDs, got {len(dependency_jobs)}")
    if args.validate_only:
        print(
            "PASS: validated fail-closed finalizer "
            f"dependencies={len(dependency_jobs)} preserved_v13=28 replacements_v14=16"
        )
        return 0

    logs_root = OUTPUT_ROOT / "logs"
    logs_root.mkdir(parents=True, exist_ok=True)
    slurm_output = logs_root / "finalizer.%j.slurm.log"
    dependency = "afterany:" + ":".join(dependency_jobs)
    command = [
        "sbatch",
        "--parsable",
        "--partition=normal",
        "--ntasks=1",
        "--cpus-per-task=4",
        "--mem=32G",
        "--time=01:30:00",
        "--exclude=n2cn0167",
        f"--dependency={dependency}",
        "--job-name=clean22_v13_finalize",
        f"--output={slurm_output}",
        str(REPO_ROOT / "scripts/slurm/clean_mixed_followup_consolidate.sh"),
    ]
    result = subprocess.run(command, cwd=REPO_ROOT, check=True, capture_output=True, text=True)
    job_id = result.stdout.strip().split(";", 1)[0]
    if not job_id.isdigit():
        raise SystemExit(f"unexpected sbatch response: {result.stdout!r}")

    _write(
        MANIFEST,
        {
            "schema_version": 1,
            "job_id": job_id,
            "dependency_mode": "afterany",
            "dependency_job_ids": dependency_jobs,
            "dependency_count": len(dependency_jobs),
            "source_graphs": [
                {
                    "path": str(EVALUATION_GRAPH_V13),
                    "profiles": graph_v13.get("profiles", []),
                    "code_signature": graph_v13.get("code_signature", ""),
                    "job_count": len(jobs_v13),
                    "preserved_job_count": len(preserved_jobs),
                },
                {
                    "path": str(ROUTED_FINAL_EVAL_REPAIR_GRAPH_V14),
                    "code_signature": repair_graph_v14.get("code_signature", ""),
                    "adapter_code_sha256": repair_graph_v14.get("adapter_code_sha256", ""),
                    "root_cause": repair_graph_v14.get("root_cause", ""),
                    "replacement_job_count": len(replacement_jobs),
                    "invalid_v13_job_count": len(invalid_jobs),
                },
            ],
            "script": str(REPO_ROOT / "scripts/slurm/clean_mixed_followup_consolidate.sh"),
            "output_root": str(OUTPUT_ROOT),
            "slurm_output": str(slurm_output),
        },
    )
    print(f"PASS: finalizer job={job_id} dependencies={len(dependency_jobs)} manifest={MANIFEST}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

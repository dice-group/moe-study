#!/usr/bin/env python3
"""Submit the corrected one-GPU evaluation graph for all 22 clean runs."""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import sys
from pathlib import Path
from typing import Any


REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from pipeline.config_loader import load_pipeline_config  # noqa: E402
from pipeline.run import _resolve_stage_cfg  # noqa: E402
from pipeline.runtime import _compute_pipeline_code_signature, _resolve_profile, build_executor  # noqa: E402


RECOVERY_PROFILE = "moe_study_mixed_rank_expert_followup_clean22_recovery18_evaluation_repair_v13"
V7_PROFILE = "moe_study_mixed_rank_expert_followup_clean22_v7_evaluation_repair_v13"
RECOVERY_ROOT = REPO_ROOT / (
    "outputs/pipeline_runs/"
    "moe_study_mixed_rank_expert_followup_clean22_recovery18_active7p2h_one_node_v11"
)
V7_ROOT = REPO_ROOT / "outputs/pipeline_runs/moe_study_mixed_rank_expert_followup_clean22_active7p2h_v7"
REPAIR_ROOT = REPO_ROOT / "outputs/pipeline_runs/moe_study_mixed_rank_expert_followup_clean22_evaluation_repair_v13"
MANIFEST = REPAIR_ROOT / "logs/chain/evaluation_job_graph.json"
SUPERSEDED_MANIFEST = REPAIR_ROOT / "logs/chain/evaluation_job_graph_aborted_nested_20260719_232825.json"
RECOVERY_GRAPH = RECOVERY_ROOT / "logs/chain/job_graph_20260718_114729.json"
V7_GRAPH = REPO_ROOT / (
    "outputs/pipeline_runs/"
    "moe_study_mixed_rank_expert_followup_clean22_v7_completed4_acceptance_repair_v11/"
    "logs/chain/job_graph_20260718_115220.json"
)
V7_RUNS = (
    "moelora_tr256_e32_k8",
    "moelora_tr16_e8_k2",
    "mola_tr128_e16_k1",
    "mtllora_r8_nup32",
)
ACCEPTANCE_REPAIR_RUN = "moelora_tr16_e8_k2"
VERIFIED_GPU_NODES = {
    "n2gpu1201",
    "n2gpu1202",
    "n2gpu1212",
    "n2gpu1217",
    "n2gpu1222",
    "n2gpu1227",
}
A100_NODES = {f"n2gpu{number}" for number in range(1201, 1233)}


def _read_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"{path} is not a JSON object")
    return payload


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _write_manifest(payload: dict[str, Any]) -> None:
    MANIFEST.parent.mkdir(parents=True, exist_ok=True)
    temporary = MANIFEST.with_name(f".{MANIFEST.name}.tmp.{os.getpid()}")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temporary, MANIFEST)


def _validate_profile(profile_name: str, profile: dict[str, Any], expected_runs: set[str]) -> None:
    configured = {
        str(run.get("id", ""))
        for run in profile.get("training", {}).get("runs", [])
        if isinstance(run, dict)
    }
    if not expected_runs.issubset(configured):
        raise ValueError(f"{profile_name}: required run IDs are missing")
    for stage in ("final_eval_loss", "benchmark"):
        stage_cfg = _resolve_stage_cfg(profile, stage)
        executor = build_executor(profile, stage_cfg)
        flags = [str(item) for item in executor.extra_sbatch_flags]
        if executor.partition != "gpu" or executor.gres != "gpu:a100:1":
            raise ValueError(f"{profile_name}/{stage}: expected exactly one A100 request")
        if "--ntasks=1" not in flags:
            raise ValueError(f"{profile_name}/{stage}: missing --ntasks=1")
        if any(flag == "--nodes=1" or flag.startswith("--nodelist=") for flag in flags):
            raise ValueError(f"{profile_name}/{stage}: exclusive node flags are forbidden")
        excluded_nodes: set[str] = set()
        for flag in flags:
            if flag.startswith("--exclude="):
                excluded_nodes.update(flag.split("=", 1)[1].split(","))
        if A100_NODES - excluded_nodes != VERIFIED_GPU_NODES:
            raise ValueError(f"{profile_name}/{stage}: eligible GPU-node set changed")
        preflight = stage_cfg.get("preflight", {})
        if not (
            preflight.get("enabled") is True
            and int(preflight.get("required_gpu_count", 0)) == 1
            and preflight.get("required_gpu_name") == "A100"
            and preflight.get("check_ecc") is True
        ):
            raise ValueError(f"{profile_name}/{stage}: one-GPU health preflight changed")


def _stage_command(profile: str, stage: str, run_id: str) -> list[str]:
    return [
        sys.executable,
        "-m",
        "pipeline.run",
        "--config",
        "configs/pipeline",
        "--profile",
        profile,
        "--start-at",
        stage,
        "--stop-after",
        stage,
        "--force-stage",
        stage,
        "--executor-type",
        "local",
        "--run-id",
        run_id,
    ]


def _recovery_evidence(run_ids: set[str]) -> tuple[dict[str, dict[str, Any]], dict[str, str]]:
    graph = _read_json(RECOVERY_GRAPH)
    train_jobs = {
        str(job.get("run_id")): str(job.get("job_id"))
        for job in graph.get("jobs", [])
        if isinstance(job, dict) and job.get("stage") == "train"
    }
    if set(train_jobs) != run_ids:
        raise ValueError("recovery training provenance does not match the 18-run profile")
    evidence: dict[str, dict[str, Any]] = {}
    for run_id in sorted(run_ids):
        path = RECOVERY_ROOT / "acceptance" / run_id / "acceptance.json"
        decision = _read_json(path)
        accepted_job = str(decision.get("checks", {}).get("slurm", {}).get("job_id", ""))
        if decision.get("accepted") is not True or accepted_job != train_jobs[run_id]:
            raise ValueError(f"recovery acceptance is invalid for {run_id}")
        evidence[run_id] = {
            "type": "acceptance_json",
            "path": str(path),
            "sha256": _sha256(path),
            "accepted_train_job_id": accepted_job,
        }
    return evidence, train_jobs


def _v7_evidence() -> tuple[dict[str, dict[str, Any]], dict[str, str], dict[str, str]]:
    graph = _read_json(V7_GRAPH)
    preflight = graph.get("training_preflight", {})
    jobs = [job for job in graph.get("jobs", []) if isinstance(job, dict)]
    train_jobs = {
        str(job.get("run_id")): str(job.get("source_train_job_id"))
        for job in jobs
        if job.get("stage") == "train_acceptance"
    }
    if set(train_jobs) != set(V7_RUNS):
        raise ValueError("v7 training provenance does not match the frozen four runs")
    train_logs: dict[str, str] = {}
    for run_id in V7_RUNS:
        scanned_paths = preflight.get(run_id, {}).get("checks", {}).get("logs", {}).get(
            "scanned_paths", []
        )
        if not isinstance(scanned_paths, list) or len(scanned_paths) != 1:
            raise ValueError(f"v7 training log provenance is invalid for {run_id}")
        train_log = Path(str(scanned_paths[0]))
        if not train_log.is_file():
            raise ValueError(f"v7 training log is missing for {run_id}: {train_log}")
        train_logs[run_id] = str(train_log)
    evidence: dict[str, dict[str, Any]] = {}
    for run_id in V7_RUNS:
        decision = preflight.get(run_id, {})
        accepted_job = str(decision.get("checks", {}).get("slurm", {}).get("job_id", ""))
        if decision.get("accepted") is not True or accepted_job != train_jobs[run_id]:
            raise ValueError(f"v7 immutable preflight decision is invalid for {run_id}")
        acceptance_path = V7_ROOT / "acceptance" / run_id / "acceptance.json"
        acceptance_json = None
        if acceptance_path.is_file():
            payload = _read_json(acceptance_path)
            if payload.get("accepted") is True:
                acceptance_json = {"path": str(acceptance_path), "sha256": _sha256(acceptance_path)}
        evidence[run_id] = {
            "type": "submission_preflight_decision",
            "source_graph": str(V7_GRAPH),
            "source_graph_sha256": _sha256(V7_GRAPH),
            "accepted_train_job_id": accepted_job,
            "formal_acceptance": acceptance_json,
        }
    return evidence, train_jobs, train_logs


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument(
        "--validate-only",
        action="store_true",
        help="validate profiles and immutable training evidence without writing or submitting",
    )
    args = parser.parse_args()
    if args.dry_run and args.validate_only:
        parser.error("--dry-run and --validate-only are mutually exclusive")
    if MANIFEST.exists() and not args.dry_run:
        raise SystemExit(f"evaluation repair graph already exists: {MANIFEST}")

    config = load_pipeline_config(REPO_ROOT / "configs/pipeline")
    recovery_profile = _resolve_profile(config, RECOVERY_PROFILE)
    v7_profile = _resolve_profile(config, V7_PROFILE)
    recovery_runs = {
        str(run.get("id", ""))
        for run in recovery_profile.get("training", {}).get("runs", [])
        if isinstance(run, dict)
    }
    if len(recovery_runs) != 18:
        raise SystemExit(f"expected 18 recovery runs, found {len(recovery_runs)}")
    _validate_profile(RECOVERY_PROFILE, recovery_profile, recovery_runs)
    _validate_profile(V7_PROFILE, v7_profile, set(V7_RUNS))

    recovery_evidence, recovery_train_jobs = _recovery_evidence(recovery_runs)
    v7_evidence, v7_train_jobs, v7_train_logs = _v7_evidence()
    if args.validate_only:
        print(
            "PASS: validated one-GPU evaluation profiles and accepted training evidence "
            f"recovery_runs={len(recovery_runs)} v7_runs={len(V7_RUNS)} evaluations=44"
        )
        return 0
    timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    code_signature = _compute_pipeline_code_signature(REPO_ROOT)
    common_env = os.environ.copy()
    common_env.update(
        {
            "HF_HOME": "/scratch/hpc-prf-merlin/shared_cache/huggingface",
            "HF_DATASETS_CACHE": "/scratch/hpc-prf-merlin/shared_cache/huggingface/datasets",
            "PROOF_PIPELINE_CODE_SIG": code_signature,
            "PROOF_PIPELINE_REPO_ROOT": str(REPO_ROOT),
            "PROOF_PIPELINE_RUN_TIMESTAMP": timestamp,
            "PYTHONPATH": f"{REPO_ROOT}:{REPO_ROOT / 'LLaMA-Factory/src'}:{os.environ.get('PYTHONPATH', '')}",
            "WANDB_MODE": "disabled",
        }
    )

    script_root = REPAIR_ROOT / "logs/chain/sbatch"
    stage_log_root = REPAIR_ROOT / "logs/chain/logs"
    slurm_log_root = REPAIR_ROOT / "logs/chain/slurm"
    for path in (script_root, stage_log_root, slurm_log_root):
        path.mkdir(parents=True, exist_ok=True)
    manifest: dict[str, Any] = {
        "schema_version": 1,
        "created_utc": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
        "code_signature": code_signature,
        "dry_run": bool(args.dry_run),
        "profiles": [RECOVERY_PROFILE, V7_PROFILE],
        "allocation_probe_job_id": "33664415",
        "supersedes_manifest": str(SUPERSEDED_MANIFEST) if SUPERSEDED_MANIFEST.is_file() else None,
        "supersession_reason": (
            "The first repair graph was cancelled because the explicit local executor CLI "
            "override did not win over stage-specific Slurm executors, causing nested jobs."
            if SUPERSEDED_MANIFEST.is_file()
            else None
        ),
        "source_training_job_ids": {**recovery_train_jobs, **v7_train_jobs},
        "acceptance_evidence": {**recovery_evidence, **v7_evidence},
        "jobs": [],
    }

    acceptance_run = ACCEPTANCE_REPAIR_RUN
    acceptance_repair_count = 0
    if v7_evidence[acceptance_run]["formal_acceptance"] is None:
        # Repair the formal acceptance artifact if it is still absent. The
        # immutable submission-time decision already accepted the checkpoint.
        acceptance_executor = build_executor(
            v7_profile, _resolve_stage_cfg(v7_profile, "train_acceptance")
        )
        acceptance_script = script_root / f"repair_train_acceptance.{acceptance_run}.{timestamp}.sbatch.sh"
        acceptance_log = stage_log_root / f"repair_train_acceptance.{acceptance_run}.{timestamp}.log"
        acceptance_slurm = slurm_log_root / f"repair_train_acceptance.{acceptance_run}.{timestamp}.slurm.log"
        acceptance_env = dict(common_env)
        acceptance_env["PROOF_PIPELINE_TRAIN_JOB_ID"] = v7_train_jobs[acceptance_run]
        acceptance_env["PROOF_PIPELINE_TRAIN_LOG_PATH"] = v7_train_logs[acceptance_run]
        acceptance_job = acceptance_executor.submit(
            _stage_command(V7_PROFILE, "train_acceptance", acceptance_run),
            acceptance_env,
            args.dry_run,
            acceptance_log,
            job_name=f"tac13_{acceptance_run}",
            script_path=acceptance_script,
            slurm_output=acceptance_slurm,
        ) or f"dry_train_acceptance_{acceptance_run}"
        manifest["jobs"].append(
            {
                "stage": "train_acceptance",
                "run_id": acceptance_run,
                "job_id": acceptance_job,
                "dependency": None,
                "profile": V7_PROFILE,
                "source_train_job_id": v7_train_jobs[acceptance_run],
                "script_path": str(acceptance_script),
                "log_path": str(acceptance_log),
                "slurm_output": str(acceptance_slurm),
            }
        )
        acceptance_repair_count = 1
    _write_manifest(manifest)

    sources = [
        (RECOVERY_PROFILE, recovery_profile, sorted(recovery_runs)),
        (V7_PROFILE, v7_profile, list(V7_RUNS)),
    ]
    for profile_name, profile, run_ids in sources:
        for stage in ("final_eval_loss", "benchmark"):
            executor = build_executor(profile, _resolve_stage_cfg(profile, stage))
            for run_id in run_ids:
                script_path = script_root / f"repair_{stage}.{run_id}.{timestamp}.sbatch.sh"
                log_path = stage_log_root / f"repair_{stage}.{run_id}.{timestamp}.log"
                slurm_output = slurm_log_root / f"repair_{stage}.{run_id}.{timestamp}.slurm.log"
                job_id = executor.submit(
                    _stage_command(profile_name, stage, run_id),
                    dict(common_env),
                    args.dry_run,
                    log_path,
                    job_name=f"{'fev13' if stage == 'final_eval_loss' else 'bn13'}_{run_id}",
                    script_path=script_path,
                    slurm_output=slurm_output,
                ) or f"dry_{stage}_{run_id}"
                manifest["jobs"].append(
                    {
                        "stage": stage,
                        "run_id": run_id,
                        "job_id": job_id,
                        "dependency": None,
                        "profile": profile_name,
                        "source_train_job_id": manifest["source_training_job_ids"][run_id],
                        "script_path": str(script_path),
                        "log_path": str(log_path),
                        "slurm_output": str(slurm_output),
                    }
                )
                _write_manifest(manifest)

    downstream = [job for job in manifest["jobs"] if job["stage"] in {"final_eval_loss", "benchmark"}]
    if len(downstream) != 44 or len({job["job_id"] for job in downstream}) != 44:
        raise SystemExit("evaluation repair graph does not contain 44 unique downstream jobs")
    print(
        f"PASS: submitted acceptance_repair={acceptance_repair_count} evaluations={len(downstream)} "
        f"manifest={MANIFEST}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

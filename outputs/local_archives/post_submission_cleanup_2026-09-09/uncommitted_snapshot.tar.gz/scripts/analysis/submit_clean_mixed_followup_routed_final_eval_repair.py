#!/usr/bin/env python3
"""Resubmit final-loss evaluation for the 16 routed, non-mergeable adapters."""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import sys
from pathlib import Path
from typing import Any


REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from pipeline.config_loader import load_pipeline_config  # noqa: E402
from pipeline.run import _resolve_stage_cfg  # noqa: E402
from pipeline.runtime import _compute_pipeline_code_signature, _resolve_profile, build_executor  # noqa: E402

from submit_clean_mixed_followup_evaluation_repair import (  # noqa: E402
    RECOVERY_PROFILE,
    V7_PROFILE,
    V7_RUNS,
    _stage_command,
    _validate_profile,
)


V13_GRAPH = REPO_ROOT / (
    "outputs/pipeline_runs/moe_study_mixed_rank_expert_followup_clean22_evaluation_repair_v13/"
    "logs/chain/evaluation_job_graph.json"
)
REPAIR_ROOT = REPO_ROOT / (
    "outputs/pipeline_runs/moe_study_mixed_rank_expert_followup_clean22_routed_final_eval_repair_v14"
)
MANIFEST = REPAIR_ROOT / "logs/chain/job_graph.json"
ADAPTER_CODE = REPO_ROOT / "LLaMA-Factory/src/llamafactory/model/adapter.py"
ROUTED_KINDS = {"mola", "moelora"}


def _read_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"{path} is not a JSON object")
    return payload


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _write_manifest(payload: dict[str, Any]) -> None:
    MANIFEST.parent.mkdir(parents=True, exist_ok=True)
    temporary = MANIFEST.with_name(f".{MANIFEST.name}.tmp.{os.getpid()}")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temporary, MANIFEST)


def _run_kinds(profile: dict[str, Any]) -> dict[str, str]:
    return {
        str(run.get("id", "")): str(run.get("kind", ""))
        for run in profile.get("training", {}).get("runs", [])
        if isinstance(run, dict)
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--validate-only", action="store_true")
    args = parser.parse_args()
    if MANIFEST.exists():
        raise SystemExit(f"routed final-eval repair graph already exists: {MANIFEST}")

    config = load_pipeline_config(REPO_ROOT / "configs/pipeline")
    recovery_profile = _resolve_profile(config, RECOVERY_PROFILE)
    v7_profile = _resolve_profile(config, V7_PROFILE)
    recovery_kinds = _run_kinds(recovery_profile)
    v7_kinds = _run_kinds(v7_profile)
    recovery_runs = set(recovery_kinds)
    if len(recovery_runs) != 18:
        raise SystemExit(f"expected 18 recovery runs, found {len(recovery_runs)}")
    _validate_profile(RECOVERY_PROFILE, recovery_profile, recovery_runs)
    _validate_profile(V7_PROFILE, v7_profile, set(V7_RUNS))

    frozen_runs = recovery_runs | set(V7_RUNS)
    if len(frozen_runs) != 22 or recovery_runs & set(V7_RUNS):
        raise SystemExit("recovery and v7 source cohorts do not form a disjoint frozen 22-run set")
    kinds = {**recovery_kinds, **{run_id: v7_kinds[run_id] for run_id in V7_RUNS}}
    routed_runs = {run_id for run_id in frozen_runs if kinds[run_id] in ROUTED_KINDS}
    if len(routed_runs) != 16:
        raise SystemExit(f"expected 16 MOLA/MoE-LoRA runs, found {len(routed_runs)}")

    source_graph = _read_json(V13_GRAPH)
    source_jobs = source_graph.get("jobs", [])
    if not isinstance(source_jobs, list) or len(source_jobs) != 44:
        raise SystemExit("v13 graph must contain exactly 44 evaluation jobs")
    invalid_jobs = [
        job
        for job in source_jobs
        if isinstance(job, dict)
        and job.get("stage") == "final_eval_loss"
        and str(job.get("run_id", "")) in routed_runs
    ]
    preserved_jobs = [job for job in source_jobs if job not in invalid_jobs]
    if len(invalid_jobs) != 16 or len(preserved_jobs) != 28:
        raise SystemExit("v13 graph does not split into 16 invalid and 28 preserved evaluations")
    if len(source_graph.get("acceptance_evidence", {})) != 22:
        raise SystemExit("v13 graph does not contain acceptance evidence for all 22 runs")

    adapter_source = ADAPTER_CODE.read_text(encoding="utf-8")
    required_guards = (
        "MoE-LoRA adapters are non-mergeable; only one adapter can be loaded.",
        "MoLA adapters are non-mergeable; only one adapter can be loaded.",
    )
    if not all(guard in adapter_source for guard in required_guards):
        raise SystemExit("non-mergeable routed-adapter guards are missing")

    if args.validate_only:
        print(
            "PASS: validated routed final-eval repair "
            f"replacement_jobs={len(routed_runs)} preserved_jobs={len(preserved_jobs)}"
        )
        return 0

    timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    code_signature = _compute_pipeline_code_signature(REPO_ROOT)
    common_env = os.environ.copy()
    common_env.update(
        {
            "HF_HOME": "/scratch/hpc-prf-merlin/shared_cache/huggingface",
            "HF_DATASETS_CACHE": "/scratch/hpc-prf-merlin/shared_cache/huggingface/datasets",
            "PROOF_PIPELINE_CODE_SIG": code_signature,
            "PROOF_PIPELINE_REPO_ROOT": str(REPO_ROOT),
            "PROOF_PIPELINE_RUN_TIMESTAMP": timestamp,
            "PYTHONPATH": f"{REPO_ROOT}:{REPO_ROOT / 'LLaMA-Factory/src'}:{os.environ.get('PYTHONPATH', '')}",
            "WANDB_MODE": "disabled",
        }
    )
    script_root = REPAIR_ROOT / "logs/chain/sbatch"
    stage_log_root = REPAIR_ROOT / "logs/chain/logs"
    slurm_log_root = REPAIR_ROOT / "logs/chain/slurm"
    for path in (script_root, stage_log_root, slurm_log_root):
        path.mkdir(parents=True, exist_ok=True)

    manifest: dict[str, Any] = {
        "schema_version": 1,
        "created_utc": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
        "code_signature": code_signature,
        "adapter_code_path": str(ADAPTER_CODE),
        "adapter_code_sha256": _sha256(ADAPTER_CODE),
        "root_cause": (
            "MOLA and MoE-LoRA were incorrectly treated as mergeable during final-loss evaluation; "
            "their routing-dependent merge methods are unavailable, so merge_and_unload discarded adapters."
        ),
        "source_graph": str(V13_GRAPH),
        "source_graph_sha256": _sha256(V13_GRAPH),
        "invalid_v13_final_eval_jobs": invalid_jobs,
        "preserved_v13_jobs": preserved_jobs,
        "acceptance_evidence": source_graph["acceptance_evidence"],
        "jobs": [],
    }
    sources = [
        (RECOVERY_PROFILE, recovery_profile, sorted(recovery_runs & routed_runs)),
        (V7_PROFILE, v7_profile, sorted(set(V7_RUNS) & routed_runs)),
    ]
    for profile_name, profile, run_ids in sources:
        executor = build_executor(profile, _resolve_stage_cfg(profile, "final_eval_loss"))
        for run_id in run_ids:
            script_path = script_root / f"repair_final_eval_loss.{run_id}.{timestamp}.sbatch.sh"
            log_path = stage_log_root / f"repair_final_eval_loss.{run_id}.{timestamp}.log"
            slurm_output = slurm_log_root / f"repair_final_eval_loss.{run_id}.{timestamp}.slurm.log"
            job_id = executor.submit(
                _stage_command(profile_name, "final_eval_loss", run_id),
                dict(common_env),
                False,
                log_path,
                job_name=f"fev14_{run_id}",
                script_path=script_path,
                slurm_output=slurm_output,
            )
            if not job_id or not str(job_id).isdigit():
                raise SystemExit(f"failed to submit routed final eval for {run_id}")
            manifest["jobs"].append(
                {
                    "stage": "final_eval_loss",
                    "run_id": run_id,
                    "kind": kinds[run_id],
                    "job_id": str(job_id),
                    "dependency": None,
                    "profile": profile_name,
                    "script_path": str(script_path),
                    "log_path": str(log_path),
                    "slurm_output": str(slurm_output),
                }
            )
            _write_manifest(manifest)

    if len(manifest["jobs"]) != 16 or len({job["job_id"] for job in manifest["jobs"]}) != 16:
        raise SystemExit("routed final-eval repair graph does not contain 16 unique jobs")
    print(f"PASS: submitted routed final-eval repairs=16 manifest={MANIFEST}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

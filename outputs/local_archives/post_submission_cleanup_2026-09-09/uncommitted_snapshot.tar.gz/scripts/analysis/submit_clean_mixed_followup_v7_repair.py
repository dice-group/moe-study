#!/usr/bin/env python3
"""Reconnect the four valid v7 trainings to fresh acceptance/evaluation jobs."""

from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import sys
from pathlib import Path
from typing import Any


REPO_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO_ROOT))

from pipeline.config_loader import load_pipeline_config  # noqa: E402
from pipeline.run import _resolve_stage_cfg  # noqa: E402
from pipeline.runtime import _compute_pipeline_code_signature, _resolve_profile, build_executor  # noqa: E402
from pipeline.stages.train_acceptance import evaluate_training_run  # noqa: E402


PROFILE = "moe_study_mixed_rank_expert_followup_clean22_v7_completed4_acceptance_repair_v11"
V7_ROOT = REPO_ROOT / "outputs/pipeline_runs/moe_study_mixed_rank_expert_followup_clean22_active7p2h_v7"
TRAINING_ATTEMPTS = {
    "moelora_tr256_e32_k8": {
        "job_id": "33642399",
        "log": V7_ROOT / "logs/chain/slurm/chain_train.moelora_tr256_e32_k8.20260717_191410.slurm.log",
    },
    "moelora_tr16_e8_k2": {
        "job_id": "33642404",
        "log": V7_ROOT / "logs/chain/slurm/chain_train.moelora_tr16_e8_k2.20260717_191410.slurm.log",
    },
    "mola_tr128_e16_k1": {
        "job_id": "33642409",
        "log": V7_ROOT / "logs/chain/slurm/chain_train.mola_tr128_e16_k1.20260717_191410.slurm.log",
    },
    "mtllora_r8_nup32": {
        "job_id": "33642417",
        "log": V7_ROOT / "logs/chain/slurm/chain_train.mtllora_r8_nup32.20260717_191410.slurm.log",
    },
}


def _utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _write_manifest(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp.{os.getpid()}")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def _stage_command(stage: str, run_id: str) -> list[str]:
    return [
        sys.executable,
        "-m",
        "pipeline.run",
        "--config",
        "configs/pipeline",
        "--profile",
        PROFILE,
        "--start-at",
        stage,
        "--stop-after",
        stage,
        "--force-stage",
        stage,
        "--executor-type",
        "local",
        "--run-id",
        run_id,
    ]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    config = load_pipeline_config(REPO_ROOT / "configs/pipeline")
    profile = _resolve_profile(config, PROFILE)
    configured_ids = {str(run.get("id", "")) for run in profile.get("training", {}).get("runs", [])}
    if not set(TRAINING_ATTEMPTS).issubset(configured_ids):
        raise SystemExit("repair run IDs are not a subset of the frozen v7 profile")

    acceptance_cfg = profile.get("train_acceptance", {})
    preflight_decisions: dict[str, Any] = {}
    for run_id, attempt in TRAINING_ATTEMPTS.items():
        decision = evaluate_training_run(
            run_id=run_id,
            run_dir=V7_ROOT / "runs" / run_id,
            config=acceptance_cfg,
            log_paths=[Path(attempt["log"])],
            train_job_id=str(attempt["job_id"]),
        )
        preflight_decisions[run_id] = decision
        if not decision.get("accepted"):
            raise SystemExit(f"v7 repair preflight rejected {run_id}: {decision.get('reasons')}")

    repair_root = REPO_ROOT / str(profile["output_root"])
    logs_root = REPO_ROOT / str(profile["logs_dir"])
    chain_root = logs_root / "chain"
    script_root = chain_root / "sbatch"
    stage_log_root = chain_root / "logs"
    slurm_log_root = chain_root / "slurm"
    for path in (script_root, stage_log_root, slurm_log_root):
        path.mkdir(parents=True, exist_ok=True)

    timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    manifest_path = chain_root / f"job_graph_{timestamp}.json"
    if any(chain_root.glob("job_graph_*.json")) and not args.dry_run:
        raise SystemExit(f"repair graph already exists under {chain_root}; refusing duplicate submission")

    code_signature = _compute_pipeline_code_signature(REPO_ROOT)
    common_env = os.environ.copy()
    common_env.update(
        {
            "HF_HOME": "/scratch/hpc-prf-merlin/shared_cache/huggingface",
            "HF_DATASETS_CACHE": "/scratch/hpc-prf-merlin/shared_cache/huggingface/datasets",
            "PROOF_PIPELINE_CODE_SIG": code_signature,
            "PROOF_PIPELINE_REPO_ROOT": str(REPO_ROOT),
            "PROOF_PIPELINE_RUN_TIMESTAMP": timestamp,
            "PYTHONPATH": f"{REPO_ROOT}:{REPO_ROOT / 'LLaMA-Factory/src'}:{os.environ.get('PYTHONPATH', '')}",
            "WANDB_MODE": "disabled",
        }
    )

    manifest: dict[str, Any] = {
        "schema_version": 1,
        "created_utc": _utc_now(),
        "profile": PROFILE,
        "output_root": str(repair_root),
        "v7_training_root": str(V7_ROOT),
        "code_signature": code_signature,
        "dry_run": bool(args.dry_run),
        "training_preflight": preflight_decisions,
        "jobs": [],
    }

    acceptance_jobs: dict[str, str] = {}
    for stage in ("train_acceptance", "final_eval_loss", "benchmark"):
        executor = build_executor(profile, _resolve_stage_cfg(profile, stage))
        for run_id, attempt in TRAINING_ATTEMPTS.items():
            # The completed v7 jobs remain in sacct but have aged out of Slurm's
            # active dependency controller. Acceptance revalidates their exact
            # job ID, state, log and checkpoint before downstream work is released.
            dependency = None if stage == "train_acceptance" else f"afterok:{acceptance_jobs[run_id]}"
            stage_env = dict(common_env)
            if stage == "train_acceptance":
                stage_env["PROOF_PIPELINE_TRAIN_JOB_ID"] = str(attempt["job_id"])
                stage_env["PROOF_PIPELINE_TRAIN_LOG_PATH"] = str(attempt["log"])
            log_path = stage_log_root / f"repair_{stage}.{run_id}.{timestamp}.log"
            slurm_output = slurm_log_root / f"repair_{stage}.{run_id}.{timestamp}.slurm.log"
            script_path = script_root / log_path.with_suffix(".sbatch.sh").name
            job_id = executor.submit(
                _stage_command(stage, run_id),
                stage_env,
                args.dry_run,
                log_path,
                dependency=dependency,
                job_name=f"{stage[:5]}7fix_{run_id}",
                script_dir=script_root,
                slurm_output=slurm_output,
            )
            graph_job_id = job_id or f"dry_{stage}_{run_id}"
            if stage == "train_acceptance":
                acceptance_jobs[run_id] = graph_job_id
            manifest["jobs"].append(
                {
                    "stage": stage,
                    "run_id": run_id,
                    "job_id": graph_job_id,
                    "dependency": dependency,
                    "source_train_job_id": str(attempt["job_id"]),
                    "script_path": str(script_path),
                    "log_path": str(log_path),
                    "slurm_output": str(slurm_output),
                }
            )
            _write_manifest(manifest_path, manifest)

    print(f"PASS: submitted {len(manifest['jobs'])} v7 repair jobs; manifest={manifest_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

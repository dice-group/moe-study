#!/usr/bin/env python3
"""Fail-closed validation gate for corrected MOLA and MoE-LoRA final evaluations."""

from __future__ import annotations

import ast
import hashlib
import json
import math
import subprocess
import time
from pathlib import Path
from typing import Any


REPO_ROOT = Path(__file__).resolve().parents[2]
GRAPH = REPO_ROOT / (
    "outputs/pipeline_runs/moe_study_mixed_rank_expert_followup_clean22_routed_final_eval_repair_v14/"
    "logs/chain/job_graph.json"
)
ARCHIVE = GRAPH.parent / "invalid_v13_canary_summaries"
SOURCE_ROOT = REPO_ROOT / (
    "outputs/pipeline_runs/moe_study_mixed_rank_expert_followup_clean22_recovery18_active7p2h_one_node_v11"
)
CANARIES = {
    "moelora_tr128_e16_k8": "33664647",
    "mola_tr128_e16_k8": "33664653",
}
HELD_JOB_IDS = [
    "33664566", "33664567", "33664568",
    "33664648", "33664649", "33664650", "33664651", "33664652",
    "33664654", "33664655", "33664656", "33664657", "33664658",
    "33664659", "33664660", "33664661", "33664662",
]


def _read(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"{path} is not a JSON object")
    return payload


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _job_state(job_id: str) -> tuple[str, str]:
    for _ in range(12):
        result = subprocess.run(
            [
                "sacct", "-j", job_id, "-X", "-n", "-P",
                "-o", "JobIDRaw,State,ExitCode",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        rows = [line.split("|") for line in result.stdout.splitlines() if line.strip()]
        root = next((row for row in rows if row[0] == job_id), None)
        if root and len(root) >= 3 and root[1] not in {"PENDING", "RUNNING", "COMPLETING"}:
            return root[1], root[2]
        time.sleep(5)
    raise ValueError(f"Slurm terminal state did not become visible for canary job {job_id}")


def main() -> int:
    graph = _read(GRAPH)
    adapter_path = Path(str(graph.get("adapter_code_path", "")))
    if not adapter_path.is_absolute():
        adapter_path = REPO_ROOT / adapter_path
    if not adapter_path.is_file() or _sha256(adapter_path) != graph.get("adapter_code_sha256"):
        raise SystemExit("FAIL: routed-adapter source differs from the submitted correction")

    jobs = {
        str(job.get("run_id", "")): job
        for job in graph.get("jobs", [])
        if isinstance(job, dict)
    }
    failures: list[str] = []
    evidence: list[dict[str, Any]] = []
    for run_id, job_id in CANARIES.items():
        job = jobs.get(run_id, {})
        if str(job.get("job_id", "")) != job_id:
            failures.append(f"{run_id}: submitted job ID does not match frozen canary {job_id}")
            continue
        state, exit_code = _job_state(job_id)
        if state != "COMPLETED" or exit_code != "0:0":
            failures.append(f"{run_id}: Slurm state={state} exit_code={exit_code}")

        log_path = Path(str(job.get("slurm_output", "")))
        log = log_path.read_text(encoding="utf-8", errors="replace") if log_path.is_file() else ""
        if "[GPU_PREFLIGHT_OK] gpus=1 name=A100" not in log:
            failures.append(f"{run_id}: exact one-A100 preflight evidence is missing")
        if "Loaded adapter(s):" not in log:
            failures.append(f"{run_id}: active adapter-load evidence is missing")
        if "Merged 1 adapter(s)." in log:
            failures.append(f"{run_id}: adapter was still merged and discarded")
        if run_id.startswith("mola_"):
            marker = "Found missing adapter keys while loading the checkpoint:"
            warning_lines = [line for line in log.splitlines() if marker in line]
            if warning_lines:
                try:
                    missing_keys = ast.literal_eval(
                        warning_lines[-1].split(marker, 1)[1].strip().rstrip(".")
                    )
                except (SyntaxError, ValueError) as exc:
                    failures.append(f"{run_id}: cannot parse missing-key warning: {exc}")
                else:
                    unexpected_missing = [
                        key
                        for key in missing_keys
                        if ".moe_layer.default.experts." not in str(key)
                    ]
                    if unexpected_missing:
                        failures.append(
                            f"{run_id}: non-alias adapter keys are missing: {unexpected_missing[:5]}"
                        )

        summary_path = SOURCE_ROOT / "final_eval_loss" / "run_summaries" / f"{run_id}.json"
        old_summary_path = ARCHIVE / f"{run_id}.json"
        try:
            summary = _read(summary_path)
            old_summary = _read(old_summary_path)
            value = summary.get("run", {}).get("eval_loss")
            old_value = old_summary.get("run", {}).get("eval_loss")
            if not isinstance(value, (int, float)) or not math.isfinite(float(value)):
                failures.append(f"{run_id}: corrected eval_loss is missing or non-finite")
            if isinstance(value, (int, float)) and isinstance(old_value, (int, float)) and math.isclose(
                float(value), float(old_value), rel_tol=0.0, abs_tol=1e-10
            ):
                failures.append(f"{run_id}: corrected eval_loss is identical to the discarded result")
        except Exception as exc:
            failures.append(f"{run_id}: cannot validate corrected summary: {exc}")
            value = None
            old_value = None

        evidence.append(
            {
                "run_id": run_id,
                "job_id": job_id,
                "state": state,
                "exit_code": exit_code,
                "slurm_output": str(log_path),
                "summary": str(summary_path),
                "discarded_eval_loss": old_value,
                "corrected_eval_loss": value,
                "missing_key_warning_is_alias_only": (
                    run_id.startswith("mola_") and not any(
                        failure.startswith(f"{run_id}: non-alias adapter keys")
                        or failure.startswith(f"{run_id}: cannot parse missing-key warning")
                        for failure in failures
                    )
                ),
            }
        )

    if not failures:
        try:
            subprocess.run(["scontrol", "release", ",".join(HELD_JOB_IDS)], check=True)
        except subprocess.CalledProcessError as exc:
            failures.append(f"could not release the held replacement jobs: {exc}")

    gate_path = GRAPH.parent / "canary_gate.json"
    gate_path.write_text(
        json.dumps(
            {
                "schema_version": 1,
                "passed": not failures,
                "failures": failures,
                "adapter_code_sha256": graph.get("adapter_code_sha256", ""),
                "canaries": evidence,
                "held_job_ids": HELD_JOB_IDS,
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
    if failures:
        for failure in failures:
            print(f"FAIL: {failure}")
        return 1

    print(f"PASS: validated both routed-adapter canaries and released {len(HELD_JOB_IDS)} jobs")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

from __future__ import annotations

import csv
import hashlib
import json
import os
import urllib.request
import zipfile
from pathlib import Path

from datasets import Dataset, DatasetDict, load_from_disk
from lm_eval.utils import weighted_f1_score


ENGLISH_DATA_COMMIT = "ce17cf7ac0cb2e6c57ab7d9da4cbf5924ad313c3"
ENGLISH_SPLIT_URLS = {
    "train": f"https://raw.githubusercontent.com/cisnlp/Taxi1500/{ENGLISH_DATA_COMMIT}/eng_data/eng_train.tsv",
    "validation": f"https://raw.githubusercontent.com/cisnlp/Taxi1500/{ENGLISH_DATA_COMMIT}/eng_data/eng_dev.tsv",
    "test": f"https://raw.githubusercontent.com/cisnlp/Taxi1500/{ENGLISH_DATA_COMMIT}/eng_data/eng_test.tsv",
}
CORPUS_URLS = {
    "v3.0": "https://cis.lmu.de/~yehao/data/Taxi1500-c_v3.0.zip",
}


def _default_cache_root() -> Path:
    raw = os.environ.get("TAXI1500_CACHE_DIR", "").strip()
    if raw:
        return Path(raw).expanduser()
    return Path.home() / ".cache" / "moe-study" / "taxi1500"


def _download(url: str, dest: Path) -> Path:
    dest.parent.mkdir(parents=True, exist_ok=True)
    if not dest.exists():
        urllib.request.urlretrieve(url, dest)
    return dest


def _english_split_path(cache_root: Path, split: str) -> Path:
    return cache_root / "english_labels" / f"{split}.tsv"


def _download_english_split(cache_root: Path, split: str) -> Path:
    return _download(ENGLISH_SPLIT_URLS[split], _english_split_path(cache_root, split))


def _load_english_splits(cache_root: Path) -> dict[str, list[dict[str, str]]]:
    splits: dict[str, list[dict[str, str]]] = {}
    for split in ("train", "validation", "test"):
        rows: list[dict[str, str]] = []
        path = _download_english_split(cache_root, split)
        with path.open("r", encoding="utf-8", newline="") as handle:
            reader = csv.reader(handle, delimiter="\t")
            for row in reader:
                if len(row) < 3:
                    continue
                rows.append({"id": row[0].strip(), "label": row[1].strip(), "verse": row[2].strip()})
        splits[split] = rows
    return splits


def _corpus_zip_path(cache_root: Path, corpus_version: str) -> Path:
    return cache_root / "raw" / f"Taxi1500-c_{corpus_version}.zip"


def _download_corpus(cache_root: Path, corpus_version: str) -> Path:
    try:
        url = CORPUS_URLS[corpus_version]
    except KeyError as exc:
        raise ValueError(f"Unsupported Taxi1500 corpus version: {corpus_version}") from exc
    return _download(url, _corpus_zip_path(cache_root, corpus_version))


def _candidate_members(zf: zipfile.ZipFile, iso: str) -> list[str]:
    out: list[str] = []
    for name in zf.namelist():
        if not name.endswith(".txt"):
            continue
        base = name.rsplit("/", 1)[-1]
        if base.startswith(f"{iso}_") or base.startswith(f"{iso}-"):
            out.append(name)
    return sorted(out)


def _read_member_rows(zf: zipfile.ZipFile, member_name: str) -> dict[str, str]:
    verse_by_id: dict[str, str] = {}
    with zf.open(member_name) as handle:
        for raw_line in handle:
            line = raw_line.decode("utf-8", errors="replace").rstrip("\n")
            if not line or line.startswith("#") or "\t" not in line:
                continue
            verse_id, verse = line.split("\t", 1)
            verse_by_id[verse_id.strip()] = verse.strip()
    return verse_by_id


def _select_member(
    zf: zipfile.ZipFile,
    lang_script: str,
    union_ids: set[str],
    member_name: str | None = None,
) -> tuple[str, dict[str, str], dict[str, object]]:
    iso = lang_script.split("_", 1)[0]
    candidates = _candidate_members(zf, iso)
    if not candidates:
        raise ValueError(
            f"No released Taxi1500 corpus file found for {lang_script} (ISO {iso}) in Taxi1500-c."
        )

    if member_name is not None:
        if member_name not in candidates:
            raise ValueError(
                f"Pinned Taxi1500 member {member_name!r} is not available for "
                f"{lang_script} (ISO {iso})."
            )
        rows = _read_member_rows(zf, member_name)
        return member_name, rows, {
            "member_name": member_name,
            "labeled_overlap": len(union_ids & set(rows)),
            "total_verses": len(rows),
            "pinned": True,
        }

    best_name: str | None = None
    best_rows: dict[str, str] | None = None
    best_score: tuple[int, int, str] | None = None
    for member_name in candidates:
        rows = _read_member_rows(zf, member_name)
        score = (len(union_ids & set(rows.keys())), len(rows), member_name)
        if best_score is None or score > best_score:
            best_name = member_name
            best_rows = rows
            best_score = score

    assert best_name is not None
    assert best_rows is not None
    assert best_score is not None
    return best_name, best_rows, {
        "member_name": best_name,
        "labeled_overlap": best_score[0],
        "total_verses": best_score[1],
    }


def _built_dataset_dir(
    cache_root: Path,
    corpus_version: str,
    lang_script: str,
    member_name: str | None = None,
) -> Path:
    if member_name is None:
        return cache_root / "built" / corpus_version / lang_script
    member_digest = hashlib.sha256(member_name.encode("utf-8")).hexdigest()[:12]
    return cache_root / "built_pinned" / corpus_version / f"{lang_script}--{member_digest}"


def _build_dataset(
    cache_root: Path,
    lang_script: str,
    corpus_version: str,
    min_labeled_examples: int,
    member_name: str | None = None,
) -> DatasetDict:
    english_splits = _load_english_splits(cache_root)
    union_ids = {row["id"] for rows in english_splits.values() for row in rows}
    corpus_zip = _download_corpus(cache_root, corpus_version)
    with zipfile.ZipFile(corpus_zip) as zf:
        selected_member, verse_by_id, selection = _select_member(
            zf,
            lang_script,
            union_ids,
            member_name=member_name,
        )

    if int(selection["labeled_overlap"]) < int(min_labeled_examples):
        raise ValueError(
            f"Best released Taxi1500 corpus match for {lang_script} only covers "
            f"{selection['labeled_overlap']} labeled verses; expected at least {min_labeled_examples}."
        )

    split_datasets: dict[str, Dataset] = {}
    for split_name, rows in english_splits.items():
        split_rows = []
        for row in rows:
            verse = verse_by_id.get(row["id"])
            if verse is None:
                continue
            split_rows.append(
                {
                    "id": row["id"],
                    "label": row["label"],
                    "verse": verse,
                    "lang_script": lang_script,
                    "source_member": selected_member,
                }
            )
        split_datasets[split_name] = Dataset.from_list(split_rows)

    dataset = DatasetDict(split_datasets)
    built_dir = _built_dataset_dir(
        cache_root,
        corpus_version,
        lang_script,
        member_name=member_name,
    )
    built_dir.parent.mkdir(parents=True, exist_ok=True)
    dataset.save_to_disk(str(built_dir))
    (built_dir / "build_manifest.json").write_text(
        json.dumps(
            {
                "lang_script": lang_script,
                "corpus_version": corpus_version,
                "min_labeled_examples": min_labeled_examples,
                "selection": selection,
                "split_sizes": {split: len(ds) for split, ds in dataset.items()},
            },
            indent=2,
            sort_keys=True,
        ),
        encoding="utf-8",
    )
    return dataset


def load_taxi1500_dataset(
    lang_script: str,
    corpus_version: str = "v3.0",
    min_labeled_examples: int = 900,
    cache_root: str | None = None,
    member_name: str | None = None,
    **_: object,
) -> DatasetDict:
    root = Path(cache_root).expanduser() if cache_root else _default_cache_root()
    built_dir = _built_dataset_dir(
        root,
        corpus_version,
        lang_script,
        member_name=member_name,
    )
    if built_dir.exists():
        return load_from_disk(str(built_dir))
    return _build_dataset(
        cache_root=root,
        lang_script=lang_script,
        corpus_version=corpus_version,
        min_labeled_examples=int(min_labeled_examples),
        member_name=member_name,
    )

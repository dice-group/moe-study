# Result Analysis Notebooks

- [`moe_study_final_analysis.ipynb`](moe_study_final_analysis.ipynb) is the single source of truth for selection, mixed follow-up, final scaling, and significance conclusions.
- [`final_winners_96_200_significance.ipynb`](final_winners_96_200_significance.ipynb) is the restored visualization supplement for the final top-five 96- and 200-language benchmark results; it uses the canonical 2026-07-25 workbooks and exports figures under `../figures/final_top5_96_200_benchmarks/`.
- [`validation/`](validation/) contains operational and scientific validity checks. Some require local generated pipeline outputs.
- [`routing_analysis/`](routing_analysis/) contains routing-specific analyses.

Superseded standalone rank, expert, mixed-follow-up, and old final-winner notebooks were removed to prevent conflicting conclusions. Their history remains available in Git.

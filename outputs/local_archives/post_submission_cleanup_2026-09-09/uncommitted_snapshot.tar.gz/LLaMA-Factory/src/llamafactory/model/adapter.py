# Copyright 2025 the LlamaFactory team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
import re
from distutils.util import strtobool
from typing import TYPE_CHECKING, Optional, Sequence, Union

import torch
from peft import (
    AdaMoleConfig,
    ColaConfig,
    GradIsoConfig,
    HMoRaConfig,
    HalaConfig,
    HydraLoraConfig,
    LangGateConfig,
    LoraConfig,
    LoraModel,
    MixLoraConfig,
    MoELoraConfig,
    MtlLoraConfig,
    MovLoraConfig,
    MoelprConfig,
    MolaConfig,
    OFTConfig,
    PeftModel,
    SoftMoeConfig,
    TaskType,
    VanillaMoELoraConfig,
    get_peft_model,
)
from transformers import AutoTokenizer
from transformers.integrations import is_deepspeed_zero3_enabled

from ..extras import logging
from ..extras.constants import EngineName
from ..extras.language import load_language_groupings, load_language_map
from .model_utils.ktransformers import get_kt_peft_model, load_kt_peft_model
from .model_utils.misc import find_all_linear_modules, find_expanded_modules
from .model_utils.quantization import QuantizationMethod
from .model_utils.unsloth import get_unsloth_peft_model, load_unsloth_peft_model
from .model_utils.visual import COMPOSITE_MODELS, get_forbidden_modules, patch_target_modules


if TYPE_CHECKING:
    from transformers import PretrainedConfig, PreTrainedModel

    from ..hparams import FinetuningArguments, ModelArguments


logger = logging.get_logger(__name__)


def _accelerate_wants_fsdp() -> bool:
    return strtobool(os.environ.get("ACCELERATE_USE_FSDP", "False")) == 1


def _build_language_metadata(language_map_spec: Optional[str]):
    language_map, families, subgroup_sizes, language_to_subgroup = load_language_groupings(language_map_spec)
    if not language_map:
        return None, None, None, None, None

    languages = sorted(language_map.keys())
    if families is None:
        families = sorted(set(language_map.values()))
    family_to_idx = {family: idx for idx, family in enumerate(families)}
    language_to_family_ids = [family_to_idx[language_map[lang]] for lang in languages]

    if language_to_subgroup is None:
        language_to_subgroup_ids = None
    else:
        language_to_subgroup_ids = [language_to_subgroup.get(lang, -1) for lang in languages]

    return languages, families, language_to_family_ids, subgroup_sizes, language_to_subgroup_ids


def _build_hydralora_head_metadata(
    *,
    main_language_list: Optional[list[str]],
    head_map_spec: Optional[str],
    head_count: int,
) -> tuple[Optional[list[int]], Optional[list[str]]]:
    if not head_map_spec:
        return None, None
    if main_language_list is None:
        raise ValueError("`hydralora_head_map` requires `language_map` to define languages.")

    head_language_list, head_family_list, head_language_to_family, _, head_language_to_subgroup_ids = (
        _build_language_metadata(head_map_spec)
    )
    if not head_language_list or not head_family_list or head_language_to_family is None:
        raise ValueError("`hydralora_head_map` must define at least one language group.")
    if head_language_list != main_language_list:
        missing = sorted(set(main_language_list) - set(head_language_list))
        extra = sorted(set(head_language_list) - set(main_language_list))
        raise ValueError(
            "`hydralora_head_map` languages must match `language_map` languages "
            f"(missing={missing}, extra={extra})."
        )
    if len(head_family_list) != head_count:
        raise ValueError(
            f"`hydralora_head_map` defines {len(head_family_list)} groups but flat HydraLoRA has "
            f"lora_num={head_count} B heads."
        )

    if head_language_to_subgroup_ids is not None and any(idx >= 0 for idx in head_language_to_subgroup_ids):
        target_ids = head_language_to_subgroup_ids
    else:
        target_ids = head_language_to_family

    invalid = [idx for idx in target_ids if idx < 0 or idx >= head_count]
    if invalid:
        raise ValueError(f"`hydralora_head_map` produced invalid B-head targets: {invalid}.")
    return target_ids, head_family_list


def _parse_optional_int_list(value: Optional[Union[str, Sequence[int]]]) -> Optional[list[int]]:
    if value is None:
        return None
    if isinstance(value, str):
        items = [item.strip() for item in value.split(",") if item.strip()]
    else:
        items = list(value)
    if not items:
        return None
    parsed = []
    for item in items:
        parsed.append(int(item))
    return parsed


def _resolve_trainable_token_setup(
    finetuning_args: "FinetuningArguments",
) -> tuple[Optional[list[str]], Optional[dict[str, list[int]]]]:
    modules_to_save = finetuning_args.additional_target
    token_range = getattr(finetuning_args, "trainable_token_range", None)
    if token_range is None:
        return modules_to_save, None

    token_range = str(token_range).strip()
    if not token_range:
        return modules_to_save, None

    sep = ":" if ":" in token_range else ","
    parts = [part.strip() for part in token_range.split(sep) if part.strip()]
    if len(parts) != 2:
        raise ValueError("`trainable_token_range` must be formatted as start:end.")

    start_id, end_id = (int(parts[0]), int(parts[1]))
    if start_id < 0 or end_id <= start_id:
        raise ValueError(f"`trainable_token_range` must be a non-empty positive range, got {token_range!r}.")

    targets = getattr(finetuning_args, "trainable_token_targets", None) or ["embed_tokens"]
    if isinstance(targets, str):
        targets = [target.strip() for target in targets.split(",") if target.strip()]
    else:
        targets = [str(target).strip() for target in targets if str(target).strip()]
    if not targets:
        raise ValueError("`trainable_token_targets` must contain at least one target when trainable tokens are enabled.")

    token_indices = list(range(start_id, end_id))
    trainable_token_indices = {target: token_indices for target in targets}
    if modules_to_save:
        target_set = set(targets)
        filtered_modules = [module for module in modules_to_save if module not in target_set]
        if len(filtered_modules) != len(modules_to_save):
            logger.info_rank0(
                "Using trainable-token rows for %s; removed overlapping modules from `additional_target`.",
                ",".join(targets),
            )
        modules_to_save = filtered_modules or None

    logger.info_rank0("Using trainable-token rows [%s, %s) for %s.", start_id, end_id, ",".join(targets))
    return modules_to_save, trainable_token_indices


def _resolve_hmora_task_token_id(
    model_args: "ModelArguments",
    finetuning_args: "FinetuningArguments",
) -> Optional[int]:
    explicit_id = getattr(finetuning_args, "hmora_task_token_id", None)
    if explicit_id is not None:
        return int(explicit_id)

    task_token = str(getattr(finetuning_args, "hmora_task_token", "?") or "?").strip()
    if not task_token:
        return None

    tokenizer_source = str(getattr(model_args, "model_name_or_path", "") or "").strip()
    if not tokenizer_source:
        return None

    try:
        tokenizer = AutoTokenizer.from_pretrained(
            tokenizer_source,
            cache_dir=model_args.cache_dir,
            revision=model_args.model_revision,
            token=model_args.hf_hub_token,
            trust_remote_code=model_args.trust_remote_code,
        )
    except Exception as exc:
        logger.warning_rank0(f"HMoRA: failed to load tokenizer for task token lookup: {exc}")
        return None

    try:
        token_id = tokenizer.convert_tokens_to_ids(task_token)
    except Exception as exc:
        logger.warning_rank0(f"HMoRA: task token id lookup failed for `{task_token}`: {exc}")
        return None

    if isinstance(token_id, int) and token_id >= 0:
        return int(token_id)

    logger.warning_rank0(f"HMoRA: task token `{task_token}` has no valid token id; task embedding will use random init.")
    return None


def _setup_full_tuning(
    model: "PreTrainedModel",
    finetuning_args: "FinetuningArguments",
    is_trainable: bool,
    cast_trainable_params_to_fp32: bool,
) -> None:
    if not is_trainable:
        return

    logger.info_rank0("Fine-tuning method: Full")
    forbidden_modules = get_forbidden_modules(model.config, finetuning_args)
    for name, param in model.named_parameters():
        if not any(forbidden_module in name for forbidden_module in forbidden_modules):
            if cast_trainable_params_to_fp32:
                param.data = param.data.to(torch.float32)
        else:
            param.requires_grad_(False)


def _setup_freeze_tuning(
    model: "PreTrainedModel",
    finetuning_args: "FinetuningArguments",
    is_trainable: bool,
    cast_trainable_params_to_fp32: bool,
) -> None:
    if not is_trainable:
        return

    logger.info_rank0("Fine-tuning method: Freeze")
    if hasattr(model.config, "text_config"):  # composite models
        config = getattr(model.config, "text_config")
    else:
        config = model.config

    num_layers = (
        getattr(config, "num_hidden_layers", None)
        or getattr(config, "num_layers", None)
        or getattr(config, "n_layer", None)
    )
    if not num_layers:
        raise ValueError("Current model does not support freeze tuning.")

    if finetuning_args.use_llama_pro:
        if num_layers % finetuning_args.freeze_trainable_layers != 0:
            raise ValueError(
                f"`num_layers` {num_layers} should be "
                f"divisible by `num_layer_trainable` {finetuning_args.freeze_trainable_layers}."
            )

        stride = num_layers // finetuning_args.freeze_trainable_layers
        trainable_layer_ids = range(stride - 1, num_layers + stride - 1, stride)
    elif finetuning_args.freeze_trainable_layers > 0:  # fine-tuning the last n layers if num_layer_trainable > 0
        trainable_layer_ids = range(max(0, num_layers - finetuning_args.freeze_trainable_layers), num_layers)
    else:  # fine-tuning the first n layers if num_layer_trainable < 0
        trainable_layer_ids = range(min(-finetuning_args.freeze_trainable_layers, num_layers))

    hidden_modules = set()
    non_hidden_modules = set()
    for name, _ in model.named_parameters():
        if ".0." in name:
            hidden_modules.add(name.split(".0.")[-1].split(".")[0])
        elif ".1." in name:  # MoD starts from layer 1
            hidden_modules.add(name.split(".1.")[-1].split(".")[0])

        if re.search(r"\.\d+\.", name) is None:
            non_hidden_modules.add(name.split(".")[-2])  # remove weight/bias

    trainable_layers = []
    for module_name in finetuning_args.freeze_trainable_modules:
        if module_name != "all" and module_name not in hidden_modules:
            raise ValueError(
                "Module {} is not found, please choose from {}".format(module_name, ", ".join(hidden_modules))
            )

        for idx in trainable_layer_ids:
            trainable_layers.append(".{:d}.{}".format(idx, module_name if module_name != "all" else ""))

    if finetuning_args.freeze_extra_modules:
        for module_name in finetuning_args.freeze_extra_modules:
            if module_name not in non_hidden_modules:
                raise ValueError(
                    "Module {} is not found, please choose from {}".format(module_name, ", ".join(non_hidden_modules))
                )

            trainable_layers.append(module_name)

    model_type = getattr(model.config, "model_type", None)
    if not finetuning_args.freeze_multi_modal_projector and model_type in COMPOSITE_MODELS:
        trainable_layers.append(COMPOSITE_MODELS[model_type].projector_key)

    forbidden_modules = get_forbidden_modules(model.config, finetuning_args)
    for name, param in model.named_parameters():
        if any(trainable_layer in name for trainable_layer in trainable_layers) and not any(
            forbidden_module in name for forbidden_module in forbidden_modules
        ):
            if cast_trainable_params_to_fp32:
                param.data = param.data.to(torch.float32)
        else:
            param.requires_grad_(False)

    logger.info_rank0("Set trainable layers: {}".format(",".join(trainable_layers)))


def _setup_lora_tuning(
    config: "PretrainedConfig",
    model: "PreTrainedModel",
    model_args: "ModelArguments",
    finetuning_args: "FinetuningArguments",
    is_trainable: bool,
    cast_trainable_params_to_fp32: bool,
) -> "PeftModel":
    if is_trainable:
        if finetuning_args.finetuning_type == "oft":
            logger.info_rank0("Fine-tuning method: OFT")
        else:
            logger.info_rank0("Fine-tuning method: {}".format("DoRA" if finetuning_args.use_dora else "LoRA"))

    adapter_to_resume = None
    language_map = None
    target_modules: list[str] = []

    if model_args.adapter_name_or_path is not None:
        is_mergeable = True
        if getattr(model, "quantization_method", None):  # merge lora in quantized model is unstable
            assert len(model_args.adapter_name_or_path) == 1, "Quantized model only accepts a single adapter."
            is_mergeable = False

        if is_deepspeed_zero3_enabled():
            assert len(model_args.adapter_name_or_path) == 1, "Cannot use multiple adapters in DeepSpeed ZeRO-3."
            is_mergeable = False

        if model_args.use_kt:
            assert len(model_args.adapter_name_or_path) == 1, "KTransformers model only accepts a single adapter"
            is_mergeable = False

        if model_args.use_unsloth:
            assert len(model_args.adapter_name_or_path) == 1, "Unsloth model only accepts a single adapter."
            is_mergeable = False

        if (is_trainable and not finetuning_args.create_new_adapter) or (not is_mergeable):
            adapter_to_merge = model_args.adapter_name_or_path[:-1]
            adapter_to_resume = model_args.adapter_name_or_path[-1]
        else:
            adapter_to_merge = model_args.adapter_name_or_path

        init_kwargs = {
            "subfolder": model_args.adapter_folder,
            "offload_folder": model_args.offload_folder,
            "cache_dir": model_args.cache_dir,
            "revision": model_args.model_revision,
            "token": model_args.hf_hub_token,
        }

        if model_args.use_kt:
            if model_args.infer_backend != EngineName.KT:
                raise ValueError(
                    "We should use ktransformers as backend to infer the adapter fine-tuned by ktransformers."
                )

        for adapter in adapter_to_merge:
            model: LoraModel = PeftModel.from_pretrained(model, adapter, **init_kwargs)
            model = model.merge_and_unload()

        if len(adapter_to_merge) > 0:
            logger.info_rank0(f"Merged {len(adapter_to_merge)} adapter(s).")

        if adapter_to_resume is not None:  # resume lora training
            if model_args.use_kt:
                model = load_kt_peft_model(model_args, model)
            elif model_args.use_unsloth:
                model = load_unsloth_peft_model(config, model_args, finetuning_args, is_trainable=is_trainable)
            else:
                model = PeftModel.from_pretrained(model, adapter_to_resume, is_trainable=is_trainable, **init_kwargs)

        logger.info_rank0("Loaded adapter(s): {}".format(",".join(model_args.adapter_name_or_path)))

    if is_trainable and adapter_to_resume is None:  # create new lora weights while training
        if len(finetuning_args.lora_target) == 1 and finetuning_args.lora_target[0] == "all":
            target_modules = find_all_linear_modules(model, finetuning_args.freeze_vision_tower)
        else:
            target_modules = finetuning_args.lora_target

        if model_args.use_kt:
            new_list = []
            for m in target_modules:
                if m in ("down_proj", "up_proj", "gate_proj"):
                    new_list.extend([f"mlp.{m}", f"shared_experts.{m}"])
                elif m not in ("generate_linear", "orig_module", "prefill_linear"):
                    new_list.append(m)

            target_modules[:] = new_list

        if finetuning_args.use_llama_pro and target_modules is not None:
            target_modules = find_expanded_modules(model, target_modules, finetuning_args.freeze_trainable_layers)

        target_modules = patch_target_modules(model, finetuning_args, target_modules)

        if (
            finetuning_args.use_dora
            and getattr(model, "quantization_method", None) is not None
            and getattr(model, "quantization_method", None) != QuantizationMethod.BNB
        ):
            raise ValueError("DoRA is not compatible with PTQ-quantized models.")

        if model_args.resize_vocab and finetuning_args.additional_target is None:
            input_embeddings = model.get_input_embeddings()
            output_embeddings = model.get_output_embeddings()
            module_names = set()
            for name, module in model.named_modules():
                if module in [input_embeddings, output_embeddings]:
                    module_names.add(name.split(".")[-1])

            finetuning_args.additional_target = module_names
            logger.warning_rank0("Vocab has been resized, add {} to trainable params.".format(",".join(module_names)))

        modules_to_save, trainable_token_indices = _resolve_trainable_token_setup(finetuning_args)

        if finetuning_args.finetuning_type == "lora":
            peft_kwargs = {
                "r": finetuning_args.lora_rank,
                "target_modules": target_modules,
                "lora_alpha": finetuning_args.lora_alpha,
                "lora_dropout": finetuning_args.lora_dropout,
                "use_rslora": finetuning_args.use_rslora,
                "use_dora": finetuning_args.use_dora,
                "modules_to_save": modules_to_save,
                "trainable_token_indices": trainable_token_indices,
            }
            if finetuning_args.lora_layers_to_transform is not None:
                if finetuning_args.lora_layers_to_transform.lower() != "all":
                    peft_kwargs["layers_to_transform"] = [
                        int(layer_id) for layer_id in finetuning_args.lora_layers_to_transform.split(",") if layer_id.strip()
                    ]
        elif finetuning_args.finetuning_type == "oft":
            peft_kwargs = {
                "r": finetuning_args.oft_rank,
                "oft_block_size": finetuning_args.oft_block_size,
                "target_modules": target_modules,
                "module_dropout": finetuning_args.module_dropout,
                "modules_to_save": finetuning_args.additional_target,
            }

        if model_args.use_kt:
            if finetuning_args.finetuning_type == "oft":
                raise ValueError("KTransformers is currently not supported for OFT.")
            if finetuning_args.finetuning_type == "lora":
                peft_config = LoraConfig(
                    task_type=TaskType.CAUSAL_LM,
                    inference_mode=False,
                    **peft_kwargs,
                )
            else:
                raise ValueError("KTransformers is currently only supported for LoRA.")

            model = get_kt_peft_model(model, peft_config)
            print(f"KT_model:{model}")
        elif model_args.use_unsloth:
            if finetuning_args.finetuning_type == "oft":
                raise ValueError("Unsloth is currently not supported for OFT.")

            model = get_unsloth_peft_model(model, model_args, peft_kwargs)
        else:
            if finetuning_args.pissa_init:
                if finetuning_args.pissa_iter == -1:
                    logger.info_rank0("Using PiSSA initialization.")
                    peft_kwargs["init_lora_weights"] = "pissa"
                else:
                    logger.info_rank0(f"Using PiSSA initialization with FSVD steps {finetuning_args.pissa_iter}.")
                    peft_kwargs["init_lora_weights"] = f"pissa_niter_{finetuning_args.pissa_iter}"

            if finetuning_args.finetuning_type == "lora":
                peft_config = LoraConfig(
                    task_type=TaskType.CAUSAL_LM,
                    inference_mode=False,
                    **peft_kwargs,
                )
            elif finetuning_args.finetuning_type == "oft":
                peft_config = OFTConfig(
                    task_type=TaskType.CAUSAL_LM,
                    inference_mode=False,
                    **peft_kwargs,
                )
            model = get_peft_model(model, peft_config)

    if is_trainable and cast_trainable_params_to_fp32:
        for param in filter(lambda p: p.requires_grad, model.parameters()):
            param.data = param.data.to(torch.float32)

    if (
        is_trainable
        and (is_deepspeed_zero3_enabled() or _accelerate_wants_fsdp())
        and getattr(model_args, "compute_dtype", None) in (torch.float16, torch.bfloat16)
    ):
        target_dtype = model_args.compute_dtype
        if finetuning_args.finetuning_type == "moelpr":
            for name, param in model.named_parameters():
                if "moe_" in name and param.dtype != target_dtype:
                    param.data = param.data.to(target_dtype)
        for param in filter(lambda p: p.requires_grad, model.parameters()):
            if param.dtype != target_dtype:
                param.data = param.data.to(target_dtype)
        logger.info_rank0(f"FSDP/ZeRO-3 detected, casting trainable params to {target_dtype}.")

    return model


def _setup_cola_tuning(
    config: "PretrainedConfig",
    model: "PreTrainedModel",
    model_args: "ModelArguments",
    finetuning_args: "FinetuningArguments",
    is_trainable: bool,
    cast_trainable_params_to_fp32: bool,
) -> "PeftModel":
    if model_args.use_kt or model_args.use_unsloth:
        raise ValueError("CoLA is not compatible with KTransformers or Unsloth.")

    if is_trainable:
        logger.info_rank0("Fine-tuning method: COLA")

    cola_debug = getattr(finetuning_args, "cola_debug", False)
    language_map = None
    target_modules: list[str] = []
    expected_experts: Optional[int] = None
    expected_heads: Optional[list[int]] = None
    if cola_debug:
        logger.info_rank0("[COLA DEBUG] Enabled CoLA architecture + expert init verification.")

    adapter_to_resume = None

    if model_args.adapter_name_or_path is not None:
        is_mergeable = True
        if getattr(model, "quantization_method", None):  # merge lora in quantized model is unstable
            assert len(model_args.adapter_name_or_path) == 1, "Quantized model only accepts a single adapter."
            is_mergeable = False

        if is_deepspeed_zero3_enabled():
            assert len(model_args.adapter_name_or_path) == 1, "Cannot use multiple adapters in DeepSpeed ZeRO-3."
            is_mergeable = False

        if (is_trainable and not finetuning_args.create_new_adapter) or (not is_mergeable):
            adapter_to_merge = model_args.adapter_name_or_path[:-1]
            adapter_to_resume = model_args.adapter_name_or_path[-1]
        else:
            adapter_to_merge = model_args.adapter_name_or_path

        init_kwargs = {
            "subfolder": model_args.adapter_folder,
            "offload_folder": model_args.offload_folder,
            "cache_dir": model_args.cache_dir,
            "revision": model_args.model_revision,
            "token": model_args.hf_hub_token,
        }
        for adapter in adapter_to_merge:
            model: "LoraModel" = PeftModel.from_pretrained(model, adapter, **init_kwargs)
            model = model.merge_and_unload()

        if len(adapter_to_merge) > 0:
            logger.info_rank0(f"Merged {len(adapter_to_merge)} adapter(s).")

        if adapter_to_resume is not None:  # resume adapter training
            model = PeftModel.from_pretrained(model, adapter_to_resume, is_trainable=is_trainable, **init_kwargs)

        logger.info_rank0("Loaded adapter(s): {}".format(",".join(model_args.adapter_name_or_path)))

    if is_trainable and adapter_to_resume is None:
        if len(finetuning_args.lora_target) == 1 and finetuning_args.lora_target[0] == "all":
            target_modules = None
        else:
            target_modules = finetuning_args.lora_target

        if finetuning_args.use_llama_pro:
            target_modules = find_expanded_modules(model, target_modules, finetuning_args.freeze_trainable_layers)

        if target_modules is not None:
            target_modules = patch_target_modules(model, finetuning_args, target_modules)

        if model_args.resize_vocab and finetuning_args.additional_target is None:
            input_embeddings = model.get_input_embeddings()
            output_embeddings = model.get_output_embeddings()
            module_names = set()
            for name, module in model.named_modules():
                if module in [input_embeddings, output_embeddings]:
                    module_names.add(name.split(".")[-1])

            finetuning_args.additional_target = module_names
            logger.warning_rank0("Vocab has been resized, add {} to trainable params.".format(",".join(module_names)))

        expert_num_A = _parse_optional_int_list(finetuning_args.cola_expert_num_A)
        expert_num_B = _parse_optional_int_list(finetuning_args.cola_expert_num_B)

        peft_kwargs = {
            "r": finetuning_args.lora_rank,
            "target_modules": target_modules,
            "lora_alpha": finetuning_args.lora_alpha,
            "lora_dropout": finetuning_args.lora_dropout,
            "num_A": finetuning_args.num_A,
            "num_B": finetuning_args.num_B,
            "expert_num_A": expert_num_A,
            "expert_num_B": expert_num_B,
            "use_cola_experts": finetuning_args.use_cola_experts,
            "cola_num_experts": finetuning_args.cola_num_experts,
            "cola_top_k": finetuning_args.cola_top_k,
            "cola_debug": finetuning_args.cola_debug,
            "cola_strategy": finetuning_args.cola_strategy,
            "modules_to_save": finetuning_args.additional_target,
        }
        hydralora_layers_to_transform = getattr(finetuning_args, "hydralora_layers_to_transform", None)
        if hydralora_layers_to_transform is None:
            hydralora_layers_to_transform = finetuning_args.lora_layers_to_transform
        if hydralora_layers_to_transform is not None:
            if str(hydralora_layers_to_transform).lower() != "all":
                peft_kwargs["layers_to_transform"] = [
                    int(layer_id) for layer_id in str(hydralora_layers_to_transform).split(",") if layer_id.strip()
                ]
        language_map = load_language_map(finetuning_args.language_map)
        language_list, family_list, language_to_family, subgroup_sizes, language_to_subgroup_ids = _build_language_metadata(
            finetuning_args.language_map
        )
        if family_list:
            expected_experts = len(family_list)
        if finetuning_args.use_cola_experts and expected_experts:
            if finetuning_args.cola_num_experts != expected_experts:
                raise ValueError(
                    "CoLA expert config mismatch: "
                    f"cola_num_experts={finetuning_args.cola_num_experts} "
                    f"but language_map defines {expected_experts} groups."
                )
        if expert_num_B is None and finetuning_args.use_cola_experts and expected_experts:
            expert_num_B = [finetuning_args.num_B] * expected_experts
        if finetuning_args.use_cola_experts and expert_num_B is not None and expected_experts:
            if len(expert_num_B) != expected_experts:
                raise ValueError(
                    "CoLA expert head config mismatch: "
                    f"expected {expected_experts} entries but got {len(expert_num_B)}."
                )
            if any(count <= 0 for count in expert_num_B):
                raise ValueError("CoLA expert head config contains non-positive counts.")
            expected_heads = list(expert_num_B)
            peft_kwargs["expert_num_B"] = expected_heads
        peft_kwargs.update(
            {
                "language_map": language_map,
                "language_list": language_list,
                "family_list": family_list,
                "language_to_family_ids": language_to_family,
                "language_to_subgroup_ids": language_to_subgroup_ids,
                "language_column": finetuning_args.language_column,
                "language_router_mode": finetuning_args.language_router_mode,
                "language_head_router_mode": finetuning_args.language_head_router_mode,
                "language_guidance_scope": finetuning_args.language_guidance_scope,
                "language_prior_weight": finetuning_args.language_prior_weight,
                "track_router_metrics": finetuning_args.track_router_metrics,
                "language_bias_value": finetuning_args.language_bias_value,
                "language_head_bias_value": finetuning_args.language_head_bias_value,
            }
        )
        init_lora_weights = finetuning_args.cola_init_lora_weights
        if init_lora_weights is None:
            if finetuning_args.use_cola_pissa_init:
                init_lora_weights = (
                    "pissa" if finetuning_args.pissa_iter == -1 else f"pissa_niter_{finetuning_args.pissa_iter}"
                )
            else:
                init_lora_weights = True
        else:
            lowered = init_lora_weights.lower()
            if lowered in {"true", "default", "lora"}:
                init_lora_weights = True
            elif lowered in {"false", "none", "random"}:
                init_lora_weights = False
            elif lowered == "pissa" and finetuning_args.pissa_iter != -1:
                init_lora_weights = f"pissa_niter_{finetuning_args.pissa_iter}"
        peft_kwargs["init_lora_weights"] = init_lora_weights
        init_label = "default_lora" if init_lora_weights is True else init_lora_weights
        logger.info_rank0(f"CoLA adapter initialization method: {init_label}.")

        cola_config = ColaConfig(
            task_type=TaskType.CAUSAL_LM,
            inference_mode=False,
            **peft_kwargs,
        )
        model = get_peft_model(model, cola_config)

    if finetuning_args.use_cola_experts:
        sample_layer = next((m for _, m in model.named_modules() if hasattr(m, "use_cola_experts")), None)
        if sample_layer is not None:
            actual_experts = int(getattr(sample_layer, "num_experts", 0) or 0)
            actual_heads = []
            for idx in range(actual_experts):
                key = f"expert_{idx}"
                count = 0
                if hasattr(sample_layer, "num_B") and key in sample_layer.num_B:
                    count = int(sample_layer.num_B.get(key, 0) or 0)
                actual_heads.append(count)
            logger.info_rank0(
                "[COLA SETUP] experts=%s heads_per_expert=%s router_mode=%s head_router_mode=%s guidance=%s top_k=%s",
                actual_experts,
                actual_heads,
                finetuning_args.language_router_mode,
                finetuning_args.language_head_router_mode,
                finetuning_args.language_guidance_scope,
                finetuning_args.cola_top_k,
            )
            if expected_experts is not None and actual_experts != expected_experts:
                raise ValueError(
                    f"CoLA runtime experts mismatch: expected {expected_experts}, got {actual_experts}."
                )
            if expected_heads is not None and actual_heads != expected_heads:
                raise ValueError(
                    f"CoLA runtime head mismatch: expected {expected_heads}, got {actual_heads}."
                )

    if is_trainable and cast_trainable_params_to_fp32:
        for param in filter(lambda p: p.requires_grad, model.parameters()):
            param.data = param.data.to(torch.float32)

    if cola_debug:
        for _, module in model.named_modules():
            if hasattr(module, "use_cola_experts"):
                module.cola_debug = True
        logger.info_rank0("[COLA DEBUG] Attached cola_debug=True to all CoLA layers.")
        if language_map is not None:
            if isinstance(language_map, dict):
                language_count = len(language_map)
            elif isinstance(language_map, list):
                language_count = len(language_map)
            else:
                language_count = None
        else:
            language_count = None
        cola_layers = sum(1 for _, module in model.named_modules() if hasattr(module, "use_cola_experts"))
        logger.info_rank0(
            "[COLA DEBUG] Summary: layers=%d target_modules=%d languages=%s num_experts=%s top_k=%s num_A=%s num_B=%s",
            cola_layers,
            len(target_modules),
            "unknown" if language_count is None else str(language_count),
            finetuning_args.cola_num_experts,
            finetuning_args.cola_top_k,
            finetuning_args.num_A,
            finetuning_args.num_B,
        )

    return model


def _setup_mixlora_tuning(
    config: "PretrainedConfig",
    model: "PreTrainedModel",
    model_args: "ModelArguments",
    finetuning_args: "FinetuningArguments",
    is_trainable: bool,
    cast_trainable_params_to_fp32: bool,
) -> "PeftModel":
    del config
    if model_args.use_kt or model_args.use_unsloth:
        raise ValueError("MixLoRA is not compatible with KTransformers or Unsloth.")

    if is_trainable:
        logger.info_rank0("Fine-tuning method: MixLoRA")

    adapter_to_resume = None

    if model_args.adapter_name_or_path is not None:
        is_mergeable = True
        if getattr(model, "quantization_method", None):
            assert len(model_args.adapter_name_or_path) == 1, "Quantized model only accepts a single adapter."
            is_mergeable = False

        if is_deepspeed_zero3_enabled():
            assert len(model_args.adapter_name_or_path) == 1, "Cannot use multiple adapters in DeepSpeed ZeRO-3."
            is_mergeable = False

        if not is_trainable:
            if len(model_args.adapter_name_or_path) > 1:
                raise ValueError("MixLoRA evaluation supports only a single adapter_name_or_path.")
            adapter_to_merge = []
            adapter_to_resume = model_args.adapter_name_or_path[-1]
        elif (is_trainable and not finetuning_args.create_new_adapter) or (not is_mergeable):
            adapter_to_merge = model_args.adapter_name_or_path[:-1]
            adapter_to_resume = model_args.adapter_name_or_path[-1]
        else:
            adapter_to_merge = model_args.adapter_name_or_path

        init_kwargs = {
            "subfolder": model_args.adapter_folder,
            "offload_folder": model_args.offload_folder,
            "cache_dir": model_args.cache_dir,
            "revision": model_args.model_revision,
            "token": model_args.hf_hub_token,
        }
        for adapter in adapter_to_merge:
            model: "LoraModel" = PeftModel.from_pretrained(model, adapter, **init_kwargs)
            model = model.merge_and_unload()

        if len(adapter_to_merge) > 0:
            logger.info_rank0(f"Merged {len(adapter_to_merge)} adapter(s).")

        if adapter_to_resume is not None:
            model = PeftModel.from_pretrained(model, adapter_to_resume, is_trainable=is_trainable, **init_kwargs)

        logger.info_rank0("Loaded adapter(s): {}".format(",".join(model_args.adapter_name_or_path)))

    if is_trainable and adapter_to_resume is None:
        if len(finetuning_args.lora_target) == 1 and finetuning_args.lora_target[0] == "all":
            raise ValueError("MixLoRA requires explicit attention targets in `lora_target`; do not use `all`.")

        target_modules = list(finetuning_args.lora_target)
        if finetuning_args.use_llama_pro:
            target_modules = find_expanded_modules(model, target_modules, finetuning_args.freeze_trainable_layers)

        target_modules = patch_target_modules(model, finetuning_args, target_modules)
        mixlora_targets = sorted(set(target_modules).union(set(finetuning_args.mixlora_moe_target_modules or [])))

        if model_args.resize_vocab and finetuning_args.additional_target is None:
            input_embeddings = model.get_input_embeddings()
            output_embeddings = model.get_output_embeddings()
            module_names = set()
            for name, module in model.named_modules():
                if module in [input_embeddings, output_embeddings]:
                    module_names.add(name.split(".")[-1])

            finetuning_args.additional_target = module_names
            logger.warning_rank0("Vocab has been resized, add {} to trainable params.".format(",".join(module_names)))

        mixlora_config = MixLoraConfig(
            task_type=TaskType.CAUSAL_LM,
            inference_mode=False,
            r=finetuning_args.lora_rank,
            target_modules=mixlora_targets,
            lora_alpha=finetuning_args.lora_alpha,
            lora_dropout=finetuning_args.lora_dropout,
            use_rslora=finetuning_args.use_rslora,
            use_dora=finetuning_args.use_dora,
            modules_to_save=finetuning_args.additional_target,
            num_experts=finetuning_args.mixlora_num_experts,
            top_k=finetuning_args.mixlora_top_k,
            router_init_range=finetuning_args.mixlora_router_init_range,
            jitter_noise=finetuning_args.mixlora_jitter_noise,
            router_loss=finetuning_args.mixlora_router_loss,
            router_aux_loss_coef=finetuning_args.mixlora_router_aux_loss_coef,
            act_fn=finetuning_args.mixlora_act_fn,
            moe_target_modules=finetuning_args.mixlora_moe_target_modules,
            expert_lora_r=finetuning_args.mixlora_expert_lora_rank,
            expert_lora_alpha=finetuning_args.mixlora_expert_lora_alpha,
            expert_lora_dropout=finetuning_args.mixlora_expert_lora_dropout,
        )
        model = get_peft_model(model, mixlora_config)

    if is_trainable and cast_trainable_params_to_fp32:
        for param in filter(lambda p: p.requires_grad, model.parameters()):
            param.data = param.data.to(torch.float32)

    return model


def _setup_hydralora_tuning(
    config: "PretrainedConfig",
    model: "PreTrainedModel",
    model_args: "ModelArguments",
    finetuning_args: "FinetuningArguments",
    is_trainable: bool,
    cast_trainable_params_to_fp32: bool,
) -> "PeftModel":
    if model_args.use_kt or model_args.use_unsloth:
        raise ValueError("HydraLoRA is not compatible with KTransformers or Unsloth.")

    if is_trainable:
        logger.info_rank0("Fine-tuning method: HYDRALORA")

    adapter_to_resume = None
    expected_experts: Optional[int] = None
    expected_heads: Optional[list[int]] = None
    hydralora_head_groups: Optional[list[str]] = None

    if model_args.adapter_name_or_path is not None:
        if len(model_args.adapter_name_or_path) > 1:
            raise ValueError("HydraLoRA adapters are non-mergeable; only a single adapter_name_or_path is supported.")
        if is_trainable and finetuning_args.create_new_adapter:
            raise ValueError("HydraLoRA does not support create_new_adapter on top of an existing routed adapter.")
        adapter_to_resume = model_args.adapter_name_or_path[-1]
        init_kwargs = {
            "subfolder": model_args.adapter_folder,
            "offload_folder": model_args.offload_folder,
            "cache_dir": model_args.cache_dir,
            "revision": model_args.model_revision,
            "token": model_args.hf_hub_token,
        }
        model = PeftModel.from_pretrained(model, adapter_to_resume, is_trainable=is_trainable, **init_kwargs)
        logger.info_rank0("Loaded adapter(s): {}".format(",".join(model_args.adapter_name_or_path)))

    if is_trainable and adapter_to_resume is None:
        if len(finetuning_args.lora_target) == 1 and finetuning_args.lora_target[0] == "all":
            target_modules = None
        else:
            target_modules = finetuning_args.lora_target

        if finetuning_args.use_llama_pro and target_modules is not None:
            target_modules = find_expanded_modules(model, target_modules, finetuning_args.freeze_trainable_layers)

        if target_modules is not None:
            target_modules = patch_target_modules(model, finetuning_args, target_modules)

        if model_args.resize_vocab and finetuning_args.additional_target is None:
            input_embeddings = model.get_input_embeddings()
            output_embeddings = model.get_output_embeddings()
            module_names = set()
            for name, module in model.named_modules():
                if module in [input_embeddings, output_embeddings]:
                    module_names.add(name.split(".")[-1])

            finetuning_args.additional_target = module_names
            logger.warning_rank0("Vocab has been resized, add {} to trainable params.".format(",".join(module_names)))

        expert_lora_nums = _parse_optional_int_list(finetuning_args.hydralora_expert_lora_nums)

        peft_kwargs = {
            "r": finetuning_args.lora_rank,
            "target_modules": target_modules,
            "lora_alpha": finetuning_args.lora_alpha,
            "lora_dropout": finetuning_args.lora_dropout,
            "lora_num": finetuning_args.lora_num,
            "expert_lora_nums": expert_lora_nums,
            "use_hydralora_experts": finetuning_args.use_hydralora_experts,
            "num_experts": finetuning_args.hydralora_num_experts,
            "top_k": finetuning_args.hydralora_top_k,
            "head_top_k": finetuning_args.hydralora_head_top_k,
            "hydralora_debug": finetuning_args.hydralora_debug,
            "modules_to_save": finetuning_args.additional_target,
        }
        language_map = load_language_map(finetuning_args.language_map)
        language_list, family_list, language_to_family, subgroup_sizes, language_to_subgroup_ids = _build_language_metadata(
            finetuning_args.language_map
        )
        if finetuning_args.hydralora_head_map:
            language_to_subgroup_ids, hydralora_head_groups = _build_hydralora_head_metadata(
                main_language_list=language_list,
                head_map_spec=finetuning_args.hydralora_head_map,
                head_count=finetuning_args.lora_num,
            )
        if family_list:
            expected_experts = len(family_list)
        if finetuning_args.use_hydralora_experts and expected_experts:
            if finetuning_args.hydralora_num_experts != expected_experts:
                raise ValueError(
                    "Hydra expert config mismatch: "
                    f"hydralora_num_experts={finetuning_args.hydralora_num_experts} "
                    f"but language_map defines {expected_experts} groups."
                )
        if expert_lora_nums is None and subgroup_sizes and any(size > 0 for size in subgroup_sizes):
            expert_lora_nums = subgroup_sizes
        if expert_lora_nums is None and finetuning_args.use_hydralora_experts and expected_experts:
            expert_lora_nums = [finetuning_args.lora_num] * expected_experts
        if finetuning_args.use_hydralora_experts and expert_lora_nums is not None and expected_experts:
            if len(expert_lora_nums) != expected_experts:
                raise ValueError(
                    "Hydra expert head config mismatch: "
                    f"expected {expected_experts} entries but got {len(expert_lora_nums)}."
                )
            if any(count <= 0 for count in expert_lora_nums):
                raise ValueError("Hydra expert head config contains non-positive counts.")
            expected_heads = list(expert_lora_nums)
        peft_kwargs.update(
            {
                "expert_lora_nums": expert_lora_nums,
                "language_map": language_map,
                "language_list": language_list,
                "family_list": family_list,
                "language_to_family_ids": language_to_family,
                "language_to_subgroup_ids": language_to_subgroup_ids,
                "language_column": finetuning_args.language_column,
                "language_router_mode": finetuning_args.language_router_mode,
                "language_head_router_mode": finetuning_args.language_head_router_mode,
                "language_guidance_scope": finetuning_args.language_guidance_scope,
                "language_prior_weight": finetuning_args.language_prior_weight,
                "track_router_metrics": finetuning_args.track_router_metrics,
                "language_bias_value": finetuning_args.language_bias_value,
                "language_head_bias_value": finetuning_args.language_head_bias_value,
            }
        )

        hydra_config = HydraLoraConfig(
            task_type=TaskType.CAUSAL_LM,
            inference_mode=False,
            **peft_kwargs,
        )
        model = get_peft_model(model, hydra_config)

    if (not finetuning_args.use_hydralora_experts) and finetuning_args.hydralora_head_map:
        logger.info_rank0(
            "[HYDRA HEAD MAP] flat B-head targets=%s head_router_mode=%s guidance=%s prior_weight=%s",
            hydralora_head_groups,
            finetuning_args.language_head_router_mode,
            finetuning_args.language_guidance_scope,
            finetuning_args.language_prior_weight,
        )

    if finetuning_args.use_hydralora_experts:
        sample_layer = next((m for _, m in model.named_modules() if hasattr(m, "use_hydralora_experts")), None)
        if sample_layer is not None:
            actual_experts = int(getattr(sample_layer, "num_experts", 0) or 0)
            actual_heads = []
            for idx in range(actual_experts):
                key = f"expert_{idx}"
                count = 0
                if hasattr(sample_layer, "lora_num") and key in sample_layer.lora_num:
                    count = int(sample_layer.lora_num.get(key, 0) or 0)
                actual_heads.append(count)
            logger.info_rank0(
                "[HYDRA SETUP] experts=%s heads_per_expert=%s router_mode=%s head_router_mode=%s guidance=%s top_k=%s head_top_k=%s",
                actual_experts,
                actual_heads,
                finetuning_args.language_router_mode,
                finetuning_args.language_head_router_mode,
                finetuning_args.language_guidance_scope,
                finetuning_args.hydralora_top_k,
                finetuning_args.hydralora_head_top_k,
            )
            if expected_experts is not None and actual_experts != expected_experts:
                raise ValueError(
                    f"Hydra runtime experts mismatch: expected {expected_experts}, got {actual_experts}."
                )
            if expected_heads is not None and actual_heads != expected_heads:
                raise ValueError(
                    f"Hydra runtime head mismatch: expected {expected_heads}, got {actual_heads}."
                )

    if is_trainable and cast_trainable_params_to_fp32:
        for param in filter(lambda p: p.requires_grad, model.parameters()):
            param.data = param.data.to(torch.float32)

    if getattr(finetuning_args, "hydralora_debug", False):
        if language_map is not None:
            if isinstance(language_map, dict):
                language_count = len(language_map)
            elif isinstance(language_map, list):
                language_count = len(language_map)
            else:
                language_count = None
        else:
            language_count = None
        hydra_layers = sum(1 for _, module in model.named_modules() if hasattr(module, "use_hydralora_experts"))
        logger.info_rank0(
            "[HYDRA DEBUG] Summary: layers=%d target_modules=%d languages=%s num_experts=%s top_k=%s lora_num=%s",
            hydra_layers,
            len(target_modules),
            "unknown" if language_count is None else str(language_count),
            finetuning_args.hydralora_num_experts,
            finetuning_args.hydralora_top_k,
            finetuning_args.lora_num,
        )

    return model


def _setup_hala_tuning(
    config: "PretrainedConfig",
    model: "PreTrainedModel",
    model_args: "ModelArguments",
    finetuning_args: "FinetuningArguments",
    is_trainable: bool,
    cast_trainable_params_to_fp32: bool,
) -> "PeftModel":
    if model_args.use_kt or model_args.use_unsloth:
        raise ValueError("HALA is not compatible with KTransformers or Unsloth.")

    if is_trainable:
        logger.info_rank0("Fine-tuning method: HALA")

    adapter_to_resume = None
    expected_experts: Optional[int] = None
    expected_heads: Optional[list[int]] = None

    if model_args.adapter_name_or_path is not None:
        if len(model_args.adapter_name_or_path) > 1:
            raise ValueError("HALA adapters are non-mergeable; only a single adapter_name_or_path is supported.")
        if is_trainable and finetuning_args.create_new_adapter:
            raise ValueError("HALA does not support create_new_adapter on top of an existing routed adapter.")
        adapter_to_merge = []
        adapter_to_resume = model_args.adapter_name_or_path[-1]

        init_kwargs = {
            "subfolder": model_args.adapter_folder,
            "offload_folder": model_args.offload_folder,
            "cache_dir": model_args.cache_dir,
            "revision": model_args.model_revision,
            "token": model_args.hf_hub_token,
        }
        if adapter_to_resume is not None:
            model = PeftModel.from_pretrained(model, adapter_to_resume, is_trainable=is_trainable, **init_kwargs)
        logger.info_rank0("Loaded adapter(s): {}".format(",".join(model_args.adapter_name_or_path)))

    if is_trainable and adapter_to_resume is None:
        if len(finetuning_args.lora_target) == 1 and finetuning_args.lora_target[0] == "all":
            target_modules = None
        else:
            target_modules = finetuning_args.lora_target

        if finetuning_args.use_llama_pro and target_modules is not None:
            target_modules = find_expanded_modules(model, target_modules, finetuning_args.freeze_trainable_layers)

        if target_modules is not None:
            target_modules = patch_target_modules(model, finetuning_args, target_modules)

        if model_args.resize_vocab and finetuning_args.additional_target is None:
            input_embeddings = model.get_input_embeddings()
            output_embeddings = model.get_output_embeddings()
            module_names = set()
            for name, module in model.named_modules():
                if module in [input_embeddings, output_embeddings]:
                    module_names.add(name.split(".")[-1])
            finetuning_args.additional_target = module_names
            logger.warning_rank0("Vocab has been resized, add {} to trainable params.".format(",".join(module_names)))

        modules_to_save, trainable_token_indices = _resolve_trainable_token_setup(finetuning_args)
        expert_lora_nums = _parse_optional_int_list(finetuning_args.hala_expert_lora_nums)
        layers_to_transform = None
        if finetuning_args.hala_layers_to_transform is not None:
            if finetuning_args.hala_layers_to_transform.lower() != "all":
                layers_to_transform = [
                    int(layer_id) for layer_id in finetuning_args.hala_layers_to_transform.split(",") if layer_id.strip()
                ]
        peft_kwargs = {
            "r": finetuning_args.lora_rank,
            "target_modules": target_modules,
            "lora_alpha": finetuning_args.lora_alpha,
            "lora_dropout": finetuning_args.lora_dropout,
            "lora_num": finetuning_args.lora_num,
            "expert_lora_nums": expert_lora_nums,
            "use_hydralora_experts": True,
            "num_experts": finetuning_args.hala_num_experts,
            "top_k": finetuning_args.hala_top_k,
            "head_top_k": finetuning_args.hala_head_top_k,
            "hydralora_debug": finetuning_args.hala_debug,
            "hala_execution_mode": finetuning_args.hala_execution_mode,
            "hala_shared_residual": finetuning_args.hala_shared_residual,
            "hala_shared_expert_head_residual": finetuning_args.hala_shared_expert_head_residual,
            "hala_gated_shared_capacity": finetuning_args.hala_gated_shared_capacity,
            "hala_gated_shared_init_bias": finetuning_args.hala_gated_shared_init_bias,
            "hala_balance_loss_coef": finetuning_args.hala_balance_loss_coef,
            "hala_balance_loss_kind": finetuning_args.hala_balance_loss_kind,
            "hala_balance_target": finetuning_args.hala_balance_target,
            "modules_to_save": modules_to_save,
            "trainable_token_indices": trainable_token_indices,
        }
        if layers_to_transform is not None:
            peft_kwargs["layers_to_transform"] = layers_to_transform
        language_map = load_language_map(finetuning_args.language_map)
        language_list, family_list, language_to_family, subgroup_sizes, language_to_subgroup_ids = _build_language_metadata(
            finetuning_args.language_map
        )
        if family_list:
            expected_experts = len(family_list)
        if expected_experts and finetuning_args.hala_num_experts != expected_experts:
            raise ValueError(
                "HALA expert config mismatch: "
                f"hala_num_experts={finetuning_args.hala_num_experts} "
                f"but language_map defines {expected_experts} groups."
            )
        if expert_lora_nums is None and subgroup_sizes and any(size > 0 for size in subgroup_sizes):
            expert_lora_nums = subgroup_sizes
        if expert_lora_nums is None and expected_experts:
            expert_lora_nums = [finetuning_args.lora_num] * expected_experts
        if expert_lora_nums is not None and expected_experts:
            if len(expert_lora_nums) != expected_experts:
                raise ValueError(
                    "HALA expert head config mismatch: "
                    f"expected {expected_experts} entries but got {len(expert_lora_nums)}."
                )
            if any(count <= 0 for count in expert_lora_nums):
                raise ValueError("HALA expert head config contains non-positive counts.")
            expected_heads = list(expert_lora_nums)
        peft_kwargs.update(
            {
                "expert_lora_nums": expert_lora_nums,
                "language_map": language_map,
                "language_list": language_list,
                "family_list": family_list,
                "language_to_family_ids": language_to_family,
                "language_to_subgroup_ids": language_to_subgroup_ids,
                "language_column": finetuning_args.language_column,
                "language_router_mode": finetuning_args.language_router_mode,
                "language_head_router_mode": finetuning_args.language_head_router_mode,
                "language_guidance_scope": finetuning_args.language_guidance_scope,
                "language_prior_weight": finetuning_args.language_prior_weight,
                "track_router_metrics": finetuning_args.track_router_metrics,
                "language_bias_value": finetuning_args.language_bias_value,
                "language_head_bias_value": finetuning_args.language_head_bias_value,
            }
        )
        hala_config = HalaConfig(task_type=TaskType.CAUSAL_LM, inference_mode=False, **peft_kwargs)
        model = get_peft_model(model, hala_config)

    sample_layer = next((m for _, m in model.named_modules() if hasattr(m, "use_hydralora_experts")), None)
    if sample_layer is not None:
        actual_experts = int(getattr(sample_layer, "num_experts", 0) or 0)
        actual_heads = []
        for idx in range(actual_experts):
            key = f"expert_{idx}"
            count = 0
            if hasattr(sample_layer, "lora_num") and key in sample_layer.lora_num:
                count = int(sample_layer.lora_num.get(key, 0) or 0)
            actual_heads.append(count)
        logger.info_rank0(
            "[HALA SETUP] mode=%s shared_residual=%s shared_expert_head=%s gated_shared_capacity=%s experts=%s heads_per_expert=%s layers=%s router_mode=%s head_router_mode=%s guidance=%s top_k=%s head_top_k=%s",
            finetuning_args.hala_execution_mode,
            finetuning_args.hala_shared_residual,
            finetuning_args.hala_shared_expert_head_residual,
            finetuning_args.hala_gated_shared_capacity,
            actual_experts,
            actual_heads,
            finetuning_args.hala_layers_to_transform or "all",
            finetuning_args.language_router_mode,
            finetuning_args.language_head_router_mode,
            finetuning_args.language_guidance_scope,
            finetuning_args.hala_top_k,
            finetuning_args.hala_head_top_k,
        )
        if expected_experts is not None and actual_experts != expected_experts:
            raise ValueError(f"HALA runtime experts mismatch: expected {expected_experts}, got {actual_experts}.")
        if expected_heads is not None and actual_heads != expected_heads:
            raise ValueError(f"HALA runtime head mismatch: expected {expected_heads}, got {actual_heads}.")

    if is_trainable and cast_trainable_params_to_fp32:
        for param in filter(lambda p: p.requires_grad, model.parameters()):
            param.data = param.data.to(torch.float32)

    return model


def _setup_adamole_tuning(
    config: "PretrainedConfig",
    model: "PreTrainedModel",
    model_args: "ModelArguments",
    finetuning_args: "FinetuningArguments",
    is_trainable: bool,
    cast_trainable_params_to_fp32: bool,
) -> "PeftModel":
    if finetuning_args.use_dora or finetuning_args.use_rslora:
        raise ValueError("AdaMoLE currently does not support DoRA or rank-stabilized LoRA weights.")
    if model_args.use_unsloth or model_args.use_kt:
        raise ValueError("AdaMoLE is not compatible with KTransformers or Unsloth.")

    if is_trainable:
        logger.info_rank0("Fine-tuning method: AdaMoLE")

    adapter_to_resume = None

    if model_args.adapter_name_or_path is not None:
        is_mergeable = True
        if getattr(model, "quantization_method", None):
            assert len(model_args.adapter_name_or_path) == 1, "Quantized model only accepts a single adapter."
            is_mergeable = False

        if is_deepspeed_zero3_enabled():
            assert len(model_args.adapter_name_or_path) == 1, "Cannot use multiple adapters in DeepSpeed ZeRO-3."
            is_mergeable = False

        if (is_trainable and not finetuning_args.create_new_adapter) or (not is_mergeable):
            adapter_to_merge = model_args.adapter_name_or_path[:-1]
            adapter_to_resume = model_args.adapter_name_or_path[-1]
        else:
            adapter_to_merge = model_args.adapter_name_or_path

        init_kwargs = {
            "subfolder": model_args.adapter_folder,
            "offload_folder": model_args.offload_folder,
            "cache_dir": model_args.cache_dir,
            "revision": model_args.model_revision,
            "token": model_args.hf_hub_token,
        }
        for adapter in adapter_to_merge:
            model: "LoraModel" = PeftModel.from_pretrained(model, adapter, **init_kwargs)
            model = model.merge_and_unload()

        if len(adapter_to_merge) > 0:
            logger.info_rank0(f"Merged {len(adapter_to_merge)} adapter(s).")

        if adapter_to_resume is not None:  # resume adapter training
            model = PeftModel.from_pretrained(model, adapter_to_resume, is_trainable=is_trainable, **init_kwargs)

        logger.info_rank0("Loaded adapter(s): {}".format(",".join(model_args.adapter_name_or_path)))

    if is_trainable and adapter_to_resume is None:
        if len(finetuning_args.lora_target) == 1 and finetuning_args.lora_target[0] == "all":
            target_modules = None
        else:
            target_modules = finetuning_args.lora_target

        if finetuning_args.use_llama_pro and target_modules is not None:
            target_modules = find_expanded_modules(model, target_modules, finetuning_args.freeze_trainable_layers)

        if target_modules is not None:
            target_modules = patch_target_modules(model, finetuning_args, target_modules)

        if model_args.resize_vocab and finetuning_args.additional_target is None:
            input_embeddings = model.get_input_embeddings()
            output_embeddings = model.get_output_embeddings()
            module_names = set()
            for name, module in model.named_modules():
                if module in [input_embeddings, output_embeddings]:
                    module_names.add(name.split(".")[-1])

            finetuning_args.additional_target = module_names
            logger.warning_rank0("Vocab has been resized, add {} to trainable params.".format(",".join(module_names)))

        peft_kwargs = {
            "r": finetuning_args.lora_rank,
            "target_modules": target_modules,
            "lora_alpha": finetuning_args.lora_alpha,
            "lora_dropout": finetuning_args.lora_dropout,
            "modules_to_save": finetuning_args.additional_target,
        }

        if finetuning_args.pissa_init:
            if finetuning_args.pissa_iter == -1:
                logger.info_rank0("Using PiSSA initialization.")
                peft_kwargs["init_lora_weights"] = "pissa"
            else:
                logger.info_rank0(f"Using PiSSA initialization with FSVD steps {finetuning_args.pissa_iter}.")
                peft_kwargs["init_lora_weights"] = f"pissa_niter_{finetuning_args.pissa_iter}"

        adamole_config = AdaMoleConfig(
            task_type=TaskType.CAUSAL_LM,
            inference_mode=False,
            num_experts=finetuning_args.adamole_num_experts,
            max_threshold=finetuning_args.adamole_max_threshold,
            debug_mode=finetuning_args.adamole_debug_mode,
            **peft_kwargs,
        )
        model = get_peft_model(model, adamole_config)

    if is_trainable and cast_trainable_params_to_fp32:
        for param in filter(lambda p: p.requires_grad, model.parameters()):
            param.data = param.data.to(torch.float32)

    return model


def _setup_moelora_tuning(
    config: "PretrainedConfig",
    model: "PreTrainedModel",
    model_args: "ModelArguments",
    finetuning_args: "FinetuningArguments",
    is_trainable: bool,
    cast_trainable_params_to_fp32: bool,
) -> "PeftModel":
    if finetuning_args.use_dora:
        raise ValueError("MoE-LoRA currently does not support DoRA.")
    if finetuning_args.pissa_init:
        raise ValueError("MoE-LoRA currently does not support PiSSA initialization.")
    if model_args.use_unsloth or model_args.use_kt:
        raise ValueError("MoE-LoRA is not compatible with KTransformers or Unsloth.")

    if is_trainable:
        logger.info_rank0("Fine-tuning method: MoE-LoRA")

    adapter_to_resume = None

    if model_args.adapter_name_or_path is not None:
        # MoE-LoRA deltas are selected dynamically by the language/task router.
        # LinearMoELoraLayer.merge() is intentionally unavailable, so treating
        # the adapter as mergeable silently drops it during evaluation.
        is_mergeable = False
        if len(model_args.adapter_name_or_path) > 1:
            raise ValueError("MoE-LoRA adapters are non-mergeable; only one adapter can be loaded.")
        if getattr(model, "quantization_method", None):
            assert len(model_args.adapter_name_or_path) == 1, "Quantized model only accepts a single adapter."
            is_mergeable = False

        if is_deepspeed_zero3_enabled():
            assert len(model_args.adapter_name_or_path) == 1, "Cannot use multiple adapters in DeepSpeed ZeRO-3."
            is_mergeable = False

        if (is_trainable and not finetuning_args.create_new_adapter) or (not is_mergeable):
            adapter_to_merge = model_args.adapter_name_or_path[:-1]
            adapter_to_resume = model_args.adapter_name_or_path[-1]
        else:
            adapter_to_merge = model_args.adapter_name_or_path

        init_kwargs = {
            "subfolder": model_args.adapter_folder,
            "offload_folder": model_args.offload_folder,
            "cache_dir": model_args.cache_dir,
            "revision": model_args.model_revision,
            "token": model_args.hf_hub_token,
        }
        for adapter in adapter_to_merge:
            model: "LoraModel" = PeftModel.from_pretrained(model, adapter, **init_kwargs)
            model = model.merge_and_unload()

        if len(adapter_to_merge) > 0:
            logger.info_rank0(f"Merged {len(adapter_to_merge)} adapter(s).")

        if adapter_to_resume is not None:
            model = PeftModel.from_pretrained(model, adapter_to_resume, is_trainable=is_trainable, **init_kwargs)

        logger.info_rank0("Loaded adapter(s): {}".format(",".join(model_args.adapter_name_or_path)))

    if is_trainable and adapter_to_resume is None:
        if len(finetuning_args.lora_target) == 1 and finetuning_args.lora_target[0] == "all":
            target_modules = find_all_linear_modules(model, finetuning_args.freeze_vision_tower)
        else:
            target_modules = finetuning_args.lora_target

        if finetuning_args.use_llama_pro:
            target_modules = find_expanded_modules(model, target_modules, finetuning_args.freeze_trainable_layers)

        target_modules = patch_target_modules(model, finetuning_args, target_modules)

        if model_args.resize_vocab and finetuning_args.additional_target is None:
            input_embeddings = model.get_input_embeddings()
            output_embeddings = model.get_output_embeddings()
            module_names = set()
            for name, module in model.named_modules():
                if module in [input_embeddings, output_embeddings]:
                    module_names.add(name.split(".")[-1])

            finetuning_args.additional_target = module_names
            logger.warning_rank0("Vocab has been resized, add {} to trainable params.".format(",".join(module_names)))

        peft_kwargs = {
            "r": finetuning_args.lora_rank,
            "target_modules": target_modules,
            "lora_alpha": finetuning_args.lora_alpha,
            "lora_dropout": finetuning_args.lora_dropout,
            "modules_to_save": finetuning_args.additional_target,
        }

        routing_id_count = finetuning_args.moelora_task_num
        language_map = load_language_map(finetuning_args.language_map)
        if language_map is not None:
            language_count = len(language_map)
            if routing_id_count == 1:
                routing_id_count = language_count
                logger.info_rank0(
                    f"MoE-LoRA: inferred `moelora_task_num={routing_id_count}` from language_map size."
                )
            elif routing_id_count < language_count:
                raise ValueError(
                    f"`moelora_task_num` ({routing_id_count}) must be >= number of language ids ({language_count})."
                )

        moelora_config = MoELoraConfig(
            task_type=TaskType.CAUSAL_LM,
            inference_mode=False,
            expert_num=finetuning_args.moelora_num_experts,
            task_num=routing_id_count,
            task_embedding_dim=finetuning_args.moelora_task_embedding_dim,
            gate_top_k=finetuning_args.moelora_sparse_top_k,
            gate_temperature=finetuning_args.moelora_gate_temperature,
            **peft_kwargs,
        )
        model = get_peft_model(model, moelora_config)

    if is_trainable and cast_trainable_params_to_fp32:
        for param in filter(lambda p: p.requires_grad, model.parameters()):
            param.data = param.data.to(torch.float32)

    return model


def _setup_mtllora_tuning(
    config: "PretrainedConfig",
    model: "PreTrainedModel",
    model_args: "ModelArguments",
    finetuning_args: "FinetuningArguments",
    is_trainable: bool,
    cast_trainable_params_to_fp32: bool,
) -> "PeftModel":
    if finetuning_args.use_dora:
        raise ValueError("MTL-LoRA currently does not support DoRA.")
    if finetuning_args.pissa_init:
        raise ValueError("MTL-LoRA currently does not support PiSSA initialization.")
    if model_args.use_unsloth or model_args.use_kt:
        raise ValueError("MTL-LoRA is not compatible with KTransformers or Unsloth.")

    if is_trainable:
        logger.info_rank0("Fine-tuning method: MTL-LoRA")

    adapter_to_resume = None

    if model_args.adapter_name_or_path is not None:
        # MTL-LoRA adapters are non-mergeable because deltas depend on task ids.
        if len(model_args.adapter_name_or_path) > 1:
            raise ValueError("MTL-LoRA does not support loading multiple adapters because merge is unavailable.")
        if getattr(model, "quantization_method", None):
            assert len(model_args.adapter_name_or_path) == 1, "Quantized model only accepts a single adapter."

        if is_deepspeed_zero3_enabled():
            assert len(model_args.adapter_name_or_path) == 1, "Cannot use multiple adapters in DeepSpeed ZeRO-3."

        adapter_to_resume = model_args.adapter_name_or_path[-1]
        init_kwargs = {
            "subfolder": model_args.adapter_folder,
            "offload_folder": model_args.offload_folder,
            "cache_dir": model_args.cache_dir,
            "revision": model_args.model_revision,
            "token": model_args.hf_hub_token,
        }
        model = PeftModel.from_pretrained(model, adapter_to_resume, is_trainable=is_trainable, **init_kwargs)
        logger.info_rank0("Loaded adapter(s): {}".format(",".join(model_args.adapter_name_or_path)))

    if is_trainable and adapter_to_resume is None:
        if len(finetuning_args.lora_target) == 1 and finetuning_args.lora_target[0] == "all":
            target_modules = find_all_linear_modules(model, finetuning_args.freeze_vision_tower)
        else:
            target_modules = finetuning_args.lora_target

        if finetuning_args.use_llama_pro:
            target_modules = find_expanded_modules(model, target_modules, finetuning_args.freeze_trainable_layers)

        target_modules = patch_target_modules(model, finetuning_args, target_modules)

        if model_args.resize_vocab and finetuning_args.additional_target is None:
            input_embeddings = model.get_input_embeddings()
            output_embeddings = model.get_output_embeddings()
            module_names = set()
            for name, module in model.named_modules():
                if module in [input_embeddings, output_embeddings]:
                    module_names.add(name.split(".")[-1])

            finetuning_args.additional_target = module_names
            logger.warning_rank0("Vocab has been resized, add {} to trainable params.".format(",".join(module_names)))

        task_num = finetuning_args.mtllora_task_num
        language_list = None
        if finetuning_args.mtllora_use_language_ids_as_task_ids:
            language_map = load_language_map(finetuning_args.language_map)
            language_list, _, _, _, _ = _build_language_metadata(finetuning_args.language_map)
            if language_map is not None:
                language_count = len(language_map)
                if task_num == 1:
                    task_num = language_count
                    logger.info_rank0(f"MTL-LoRA: inferred `mtllora_task_num={task_num}` from language_map size.")
                elif task_num < language_count:
                    raise ValueError(
                        f"`mtllora_task_num` ({task_num}) must be >= number of language ids ({language_count})."
                    )

        mtllora_config = MtlLoraConfig(
            task_type=TaskType.CAUSAL_LM,
            inference_mode=False,
            r=finetuning_args.lora_rank,
            target_modules=target_modules,
            lora_alpha=finetuning_args.lora_alpha,
            lora_dropout=finetuning_args.lora_dropout,
            use_rslora=finetuning_args.use_rslora,
            modules_to_save=finetuning_args.additional_target,
            task_num=task_num,
            num_up_projections=finetuning_args.mtllora_num_up_projections,
            temperature=finetuning_args.mtllora_temperature,
            lambda_format=finetuning_args.mtllora_lambda_format,
            use_language_ids_as_task_ids=finetuning_args.mtllora_use_language_ids_as_task_ids,
            language_list=language_list,
        )
        model = get_peft_model(model, mtllora_config)

    if is_trainable and cast_trainable_params_to_fp32:
        for param in filter(lambda p: p.requires_grad, model.parameters()):
            param.data = param.data.to(torch.float32)

    return model


def _setup_movlora_tuning(
    config: "PretrainedConfig",
    model: "PreTrainedModel",
    model_args: "ModelArguments",
    finetuning_args: "FinetuningArguments",
    is_trainable: bool,
    cast_trainable_params_to_fp32: bool,
) -> "PeftModel":
    if finetuning_args.use_dora:
        raise ValueError("MoV currently does not support DoRA.")
    if finetuning_args.pissa_init:
        raise ValueError("MoV currently does not support PiSSA initialization.")
    if model_args.use_unsloth or model_args.use_kt:
        raise ValueError("MoV is not compatible with KTransformers or Unsloth.")

    if is_trainable:
        logger.info_rank0("Fine-tuning method: MoV")

    adapter_to_resume = None

    if model_args.adapter_name_or_path is not None:
        # MoV adapters are non-mergeable; load as PEFT adapters for both train and inference.
        is_mergeable = False
        if len(model_args.adapter_name_or_path) > 1:
            raise ValueError("MoV does not support loading multiple adapters because merge is unavailable.")
        if getattr(model, "quantization_method", None):
            assert len(model_args.adapter_name_or_path) == 1, "Quantized model only accepts a single adapter."
            is_mergeable = False

        if is_deepspeed_zero3_enabled():
            assert len(model_args.adapter_name_or_path) == 1, "Cannot use multiple adapters in DeepSpeed ZeRO-3."
            is_mergeable = False

        if (is_trainable and not finetuning_args.create_new_adapter) or (not is_mergeable):
            adapter_to_merge = model_args.adapter_name_or_path[:-1]
            adapter_to_resume = model_args.adapter_name_or_path[-1]
        else:
            adapter_to_merge = model_args.adapter_name_or_path

        init_kwargs = {
            "subfolder": model_args.adapter_folder,
            "offload_folder": model_args.offload_folder,
            "cache_dir": model_args.cache_dir,
            "revision": model_args.model_revision,
            "token": model_args.hf_hub_token,
        }
        for adapter in adapter_to_merge:
            model: "LoraModel" = PeftModel.from_pretrained(model, adapter, **init_kwargs)
            model = model.merge_and_unload()

        if len(adapter_to_merge) > 0:
            logger.info_rank0(f"Merged {len(adapter_to_merge)} adapter(s).")

        if adapter_to_resume is not None:
            model = PeftModel.from_pretrained(model, adapter_to_resume, is_trainable=is_trainable, **init_kwargs)

        logger.info_rank0("Loaded adapter(s): {}".format(",".join(model_args.adapter_name_or_path)))

    if is_trainable and adapter_to_resume is None:
        if len(finetuning_args.lora_target) == 1 and finetuning_args.lora_target[0] == "all":
            target_modules = None
        else:
            target_modules = finetuning_args.lora_target

        if finetuning_args.use_llama_pro and target_modules is not None:
            target_modules = find_expanded_modules(model, target_modules, finetuning_args.freeze_trainable_layers)

        if target_modules is not None:
            target_modules = patch_target_modules(model, finetuning_args, target_modules)

        if model_args.resize_vocab and finetuning_args.additional_target is None:
            input_embeddings = model.get_input_embeddings()
            output_embeddings = model.get_output_embeddings()
            module_names = set()
            for name, module in model.named_modules():
                if module in [input_embeddings, output_embeddings]:
                    module_names.add(name.split(".")[-1])

            finetuning_args.additional_target = module_names
            logger.warning_rank0("Vocab has been resized, add {} to trainable params.".format(",".join(module_names)))

        peft_kwargs = {
            "target_modules": target_modules,
            "modules_to_save": finetuning_args.additional_target,
            "init_ia3_weights": True,
        }

        movlora_config = MovLoraConfig(
            task_type=TaskType.CAUSAL_LM,
            inference_mode=False,
            num_experts=finetuning_args.movlora_num_experts,
            router_top_k=finetuning_args.movlora_top_k,
            router_temperature=finetuning_args.movlora_router_temperature,
            router_jitter_noise=finetuning_args.movlora_router_jitter_noise,
            router_bias=finetuning_args.movlora_router_bias,
            router_init_std=finetuning_args.movlora_router_init_std,
            router_ignore_padding_tokens=finetuning_args.movlora_router_ignore_padding_tokens,
            **peft_kwargs,
        )
        model = get_peft_model(model, movlora_config)

    if is_trainable and cast_trainable_params_to_fp32:
        for param in filter(lambda p: p.requires_grad, model.parameters()):
            param.data = param.data.to(torch.float32)

    return model


def _setup_hmora_tuning(
    config: "PretrainedConfig",
    model: "PreTrainedModel",
    model_args: "ModelArguments",
    finetuning_args: "FinetuningArguments",
    is_trainable: bool,
    cast_trainable_params_to_fp32: bool,
) -> "PeftModel":
    if finetuning_args.use_dora:
        raise ValueError("HMoRA currently does not support DoRA.")
    if finetuning_args.pissa_init:
        raise ValueError("HMoRA currently does not support PiSSA initialization.")
    if model_args.use_unsloth or model_args.use_kt:
        raise ValueError("HMoRA is not compatible with KTransformers or Unsloth.")

    if is_trainable:
        logger.info_rank0("Fine-tuning method: HMoRA")

    adapter_to_resume = None

    if model_args.adapter_name_or_path is not None:
        is_mergeable = True
        if getattr(model, "quantization_method", None):
            assert len(model_args.adapter_name_or_path) == 1, "Quantized model only accepts a single adapter."
            is_mergeable = False

        if is_deepspeed_zero3_enabled():
            assert len(model_args.adapter_name_or_path) == 1, "Cannot use multiple adapters in DeepSpeed ZeRO-3."
            is_mergeable = False

        if (is_trainable and not finetuning_args.create_new_adapter) or (not is_mergeable):
            adapter_to_merge = model_args.adapter_name_or_path[:-1]
            adapter_to_resume = model_args.adapter_name_or_path[-1]
        else:
            adapter_to_merge = model_args.adapter_name_or_path

        init_kwargs = {
            "subfolder": model_args.adapter_folder,
            "offload_folder": model_args.offload_folder,
            "cache_dir": model_args.cache_dir,
            "revision": model_args.model_revision,
            "token": model_args.hf_hub_token,
        }
        for adapter in adapter_to_merge:
            model: "LoraModel" = PeftModel.from_pretrained(model, adapter, **init_kwargs)
            model = model.merge_and_unload()

        if len(adapter_to_merge) > 0:
            logger.info_rank0(f"Merged {len(adapter_to_merge)} adapter(s).")

        if adapter_to_resume is not None:
            model = PeftModel.from_pretrained(model, adapter_to_resume, is_trainable=is_trainable, **init_kwargs)

        logger.info_rank0("Loaded adapter(s): {}".format(",".join(model_args.adapter_name_or_path)))

    if is_trainable and adapter_to_resume is None:
        if len(finetuning_args.lora_target) == 1 and finetuning_args.lora_target[0] == "all":
            target_modules = find_all_linear_modules(model, finetuning_args.freeze_vision_tower)
        else:
            target_modules = finetuning_args.lora_target

        if finetuning_args.use_llama_pro:
            target_modules = find_expanded_modules(model, target_modules, finetuning_args.freeze_trainable_layers)

        target_modules = patch_target_modules(model, finetuning_args, target_modules)

        if model_args.resize_vocab and finetuning_args.additional_target is None:
            input_embeddings = model.get_input_embeddings()
            output_embeddings = model.get_output_embeddings()
            module_names = set()
            for name, module in model.named_modules():
                if module in [input_embeddings, output_embeddings]:
                    module_names.add(name.split(".")[-1])

            finetuning_args.additional_target = module_names
            logger.warning_rank0("Vocab has been resized, add {} to trainable params.".format(",".join(module_names)))

        model_type = getattr(config, "model_type", None)
        share_router_for_qkv = bool(finetuning_args.hmora_share_router_for_qkv or model_type == "bloom")
        hidden_size = (
            getattr(config, "hidden_size", None)
            or getattr(config, "n_embd", None)
            or getattr(getattr(config, "text_config", None), "hidden_size", None)
        )
        task_token_id = _resolve_hmora_task_token_id(model_args, finetuning_args)

        hmora_config = HMoRaConfig(
            task_type=TaskType.CAUSAL_LM,
            inference_mode=False,
            r=finetuning_args.lora_rank,
            target_modules=target_modules,
            lora_alpha=finetuning_args.lora_alpha,
            lora_dropout=finetuning_args.lora_dropout,
            modules_to_save=finetuning_args.additional_target,
            hidden_size=hidden_size,
            model_type=model_type,
            torch_dtype=model.dtype,
            dropout=finetuning_args.hmora_dropout,
            num_experts=finetuning_args.hmora_num_experts,
            use_hydra_lora=finetuning_args.hmora_use_hydra_lora,
            top_k_routing_strategy=finetuning_args.hmora_top_k_routing_strategy,
            top_k=finetuning_args.hmora_top_k,
            use_task_router=finetuning_args.hmora_use_task_router,
            task_router_only=finetuning_args.hmora_task_router_only,
            share_router_for_qkv=share_router_for_qkv,
            share_router_for_w_i=finetuning_args.hmora_share_router_for_w_i,
            num_router_mlp_layers=finetuning_args.hmora_num_router_mlp_layers,
            router_hidden_dim=finetuning_args.hmora_router_hidden_dim,
            epsilon_alpha=finetuning_args.hmora_epsilon_alpha,
            alpha_shift=finetuning_args.hmora_alpha_shift,
            alpha_low_bound=finetuning_args.hmora_alpha_low_bound,
            alpha_up_bound=finetuning_args.hmora_alpha_up_bound,
            use_load_balancing_loss=finetuning_args.hmora_use_load_balancing_loss,
            use_div_loss=finetuning_args.hmora_use_div_loss,
            gamma_div_certain_t=finetuning_args.hmora_gamma_div_certain_t,
            gamma_div_balance_t=finetuning_args.hmora_gamma_div_balance_t,
            gamma_div_certain_s=finetuning_args.hmora_gamma_div_certain_s,
            gamma_div_balance_s=finetuning_args.hmora_gamma_div_balance_s,
            lambda_auxiliary=finetuning_args.hmora_lambda_auxiliary,
            lambda_lm=finetuning_args.hmora_lambda_lm,
            eta_b=finetuning_args.hmora_eta_b,
            target_modules_lora=finetuning_args.hmora_target_modules_lora,
            use_language_ids_as_task_ids=finetuning_args.hmora_use_language_ids_as_task_ids,
            num_task_embeddings=finetuning_args.hmora_num_task_embeddings,
            task_token=finetuning_args.hmora_task_token,
            task_token_id=task_token_id,
            num_encoder_layer=finetuning_args.hmora_num_encoder_layer,
        )
        model = get_peft_model(model, hmora_config)

    if is_trainable and cast_trainable_params_to_fp32:
        for param in filter(lambda p: p.requires_grad, model.parameters()):
            param.data = param.data.to(torch.float32)

    return model


def _setup_mola_tuning(
    config: "PretrainedConfig",
    model: "PreTrainedModel",
    model_args: "ModelArguments",
    finetuning_args: "FinetuningArguments",
    is_trainable: bool,
    cast_trainable_params_to_fp32: bool,
) -> "PeftModel":
    if finetuning_args.use_dora or finetuning_args.use_rslora:
        raise ValueError("MoLA currently does not support DoRA or rank-stabilized LoRA weights.")
    if model_args.use_unsloth or model_args.use_kt:
        raise ValueError("MoLA is not compatible with KTransformers or Unsloth.")

    if is_trainable:
        logger.info_rank0("Fine-tuning method: MoLA")

    adapter_to_resume = None

    if model_args.adapter_name_or_path is not None:
        # MoLA uses input-dependent top-k expert routing and has no valid static
        # merge operation. Loading through merge_and_unload() discards its
        # adapter layers because LinearMolaLayer.merge() is a no-op.
        is_mergeable = False
        if len(model_args.adapter_name_or_path) > 1:
            raise ValueError("MoLA adapters are non-mergeable; only one adapter can be loaded.")
        if getattr(model, "quantization_method", None):
            assert len(model_args.adapter_name_or_path) == 1, "Quantized model only accepts a single adapter."
            is_mergeable = False

        if is_deepspeed_zero3_enabled():
            assert len(model_args.adapter_name_or_path) == 1, "Cannot use multiple adapters in DeepSpeed ZeRO-3."
            is_mergeable = False

        if (is_trainable and not finetuning_args.create_new_adapter) or (not is_mergeable):
            adapter_to_merge = model_args.adapter_name_or_path[:-1]
            adapter_to_resume = model_args.adapter_name_or_path[-1]
        else:
            adapter_to_merge = model_args.adapter_name_or_path

        init_kwargs = {
            "subfolder": model_args.adapter_folder,
            "offload_folder": model_args.offload_folder,
            "cache_dir": model_args.cache_dir,
            "revision": model_args.model_revision,
            "token": model_args.hf_hub_token,
        }
        for adapter in adapter_to_merge:
            model: "LoraModel" = PeftModel.from_pretrained(model, adapter, **init_kwargs)
            model = model.merge_and_unload()

        if len(adapter_to_merge) > 0:
            logger.info_rank0(f"Merged {len(adapter_to_merge)} adapter(s).")

        if adapter_to_resume is not None:
            model = PeftModel.from_pretrained(model, adapter_to_resume, is_trainable=is_trainable, **init_kwargs)

        logger.info_rank0("Loaded adapter(s): {}".format(",".join(model_args.adapter_name_or_path)))

    if is_trainable and adapter_to_resume is None:
        if len(finetuning_args.lora_target) == 1 and finetuning_args.lora_target[0] == "all":
            target_modules = find_all_linear_modules(model, finetuning_args.freeze_vision_tower)
        else:
            target_modules = finetuning_args.lora_target

        if finetuning_args.use_llama_pro:
            target_modules = find_expanded_modules(model, target_modules, finetuning_args.freeze_trainable_layers)

        target_modules = patch_target_modules(model, finetuning_args, target_modules)

        if model_args.resize_vocab and finetuning_args.additional_target is None:
            input_embeddings = model.get_input_embeddings()
            output_embeddings = model.get_output_embeddings()
            module_names = set()
            for name, module in model.named_modules():
                if module in [input_embeddings, output_embeddings]:
                    module_names.add(name.split(".")[-1])

            finetuning_args.additional_target = module_names
            logger.warning_rank0("Vocab has been resized, add {} to trainable params.".format(",".join(module_names)))

        peft_kwargs = {
            "r": finetuning_args.lora_rank,
            "target_modules": target_modules,
            "lora_alpha": finetuning_args.lora_alpha,
            "lora_dropout": finetuning_args.lora_dropout,
            "modules_to_save": finetuning_args.additional_target,
        }

        if finetuning_args.pissa_init:
            if finetuning_args.pissa_iter == -1:
                logger.info_rank0("Using PiSSA initialization.")
                peft_kwargs["init_lora_weights"] = "pissa"
            else:
                logger.info_rank0(f"Using PiSSA initialization with FSVD steps {finetuning_args.pissa_iter}.")
                peft_kwargs["init_lora_weights"] = f"pissa_niter_{finetuning_args.pissa_iter}"

        mola_config = MolaConfig(
            task_type=TaskType.CAUSAL_LM,
            inference_mode=False,
            mola_num_experts=finetuning_args.mola_num_experts,
            mola_top_k=finetuning_args.mola_top_k,
            mola_use_null_expert=finetuning_args.mola_use_null_expert,
            mola_num_null_experts=finetuning_args.mola_num_null_experts,
            mola_output_router_logits=finetuning_args.mola_output_router_logits,
            mola_router_aux_loss_coef=finetuning_args.mola_router_aux_loss_coef,
            mola_null_expert_penalty=finetuning_args.mola_null_expert_penalty,
            mola_aux_loss_annealing=finetuning_args.mola_aux_loss_annealing,
            mola_debug_mode=finetuning_args.mola_debug_mode,
            **peft_kwargs,
        )
        model = get_peft_model(model, mola_config)

    if is_trainable and cast_trainable_params_to_fp32:
        for param in filter(lambda p: p.requires_grad, model.parameters()):
            param.data = param.data.to(torch.float32)

    return model


def _setup_vanilla_moelora_tuning(
    config: "PretrainedConfig",
    model: "PreTrainedModel",
    model_args: "ModelArguments",
    finetuning_args: "FinetuningArguments",
    is_trainable: bool,
    cast_trainable_params_to_fp32: bool,
) -> "PeftModel":
    if finetuning_args.use_dora:
        raise ValueError("Vanilla MoE-LoRA currently does not support DoRA.")
    if finetuning_args.pissa_init:
        raise ValueError("Vanilla MoE-LoRA currently supports standard LoRA initialization only.")
    if model_args.use_unsloth or model_args.use_kt:
        raise ValueError("Vanilla MoE-LoRA is not compatible with KTransformers or Unsloth.")

    if is_trainable:
        logger.info_rank0("Fine-tuning method: Vanilla MoE-LoRA")

    adapter_to_resume = None

    if model_args.adapter_name_or_path is not None:
        is_mergeable = True
        if getattr(model, "quantization_method", None):
            assert len(model_args.adapter_name_or_path) == 1, "Quantized model only accepts a single adapter."
            is_mergeable = False

        if is_deepspeed_zero3_enabled():
            assert len(model_args.adapter_name_or_path) == 1, "Cannot use multiple adapters in DeepSpeed ZeRO-3."
            is_mergeable = False

        if (is_trainable and not finetuning_args.create_new_adapter) or (not is_mergeable):
            adapter_to_merge = model_args.adapter_name_or_path[:-1]
            adapter_to_resume = model_args.adapter_name_or_path[-1]
        else:
            adapter_to_merge = model_args.adapter_name_or_path

        init_kwargs = {
            "subfolder": model_args.adapter_folder,
            "offload_folder": model_args.offload_folder,
            "cache_dir": model_args.cache_dir,
            "revision": model_args.model_revision,
            "token": model_args.hf_hub_token,
        }
        for adapter in adapter_to_merge:
            model: "LoraModel" = PeftModel.from_pretrained(model, adapter, **init_kwargs)
            model = model.merge_and_unload()

        if len(adapter_to_merge) > 0:
            logger.info_rank0(f"Merged {len(adapter_to_merge)} adapter(s).")

        if adapter_to_resume is not None:
            model = PeftModel.from_pretrained(model, adapter_to_resume, is_trainable=is_trainable, **init_kwargs)

        logger.info_rank0("Loaded adapter(s): {}".format(",".join(model_args.adapter_name_or_path)))

    if is_trainable and adapter_to_resume is None:
        if len(finetuning_args.lora_target) == 1 and finetuning_args.lora_target[0] == "all":
            target_modules = find_all_linear_modules(model, finetuning_args.freeze_vision_tower)
        else:
            target_modules = finetuning_args.lora_target

        if finetuning_args.use_llama_pro:
            target_modules = find_expanded_modules(model, target_modules, finetuning_args.freeze_trainable_layers)

        target_modules = patch_target_modules(model, finetuning_args, target_modules)

        if model_args.resize_vocab and finetuning_args.additional_target is None:
            input_embeddings = model.get_input_embeddings()
            output_embeddings = model.get_output_embeddings()
            module_names = set()
            for name, module in model.named_modules():
                if module in [input_embeddings, output_embeddings]:
                    module_names.add(name.split(".")[-1])

            finetuning_args.additional_target = module_names
            logger.warning_rank0("Vocab has been resized, add {} to trainable params.".format(",".join(module_names)))

        peft_kwargs = {
            "r": finetuning_args.lora_rank,
            "target_modules": target_modules,
            "lora_alpha": finetuning_args.lora_alpha,
            "lora_dropout": finetuning_args.lora_dropout,
            "use_rslora": finetuning_args.use_rslora,
            "modules_to_save": finetuning_args.additional_target,
        }

        vanilla_moelora_config = VanillaMoELoraConfig(
            task_type=TaskType.CAUSAL_LM,
            inference_mode=False,
            num_experts=finetuning_args.vanilla_moelora_num_experts,
            top_k=finetuning_args.vanilla_moelora_top_k,
            router_aux_loss_coef=finetuning_args.vanilla_moelora_router_aux_loss_coef,
            router_init_range=finetuning_args.vanilla_moelora_router_init_range,
            **peft_kwargs,
        )
        model = get_peft_model(model, vanilla_moelora_config)

    if is_trainable and cast_trainable_params_to_fp32:
        for param in filter(lambda p: p.requires_grad, model.parameters()):
            param.data = param.data.to(torch.float32)

    return model


def _setup_moelpr_tuning(
    config: "PretrainedConfig",
    model: "PreTrainedModel",
    model_args: "ModelArguments",
    finetuning_args: "FinetuningArguments",
    is_trainable: bool,
    cast_trainable_params_to_fp32: bool,
) -> "PeftModel":
    if model_args.use_unsloth or model_args.use_kt:
        raise ValueError("MoE-LPR is not compatible with KTransformers or Unsloth.")

    if is_trainable:
        logger.info_rank0(f"Fine-tuning method: MoE-LPR (Stage {finetuning_args.moelpr_stage})")

    if hasattr(config, "text_config"):
        text_config = config.text_config
    else:
        text_config = config

    num_layers = (
        getattr(text_config, "num_hidden_layers", None)
        or getattr(text_config, "num_layers", None)
        or getattr(text_config, "n_layer", None)
    )
    if num_layers is None or num_layers <= 0:
        raise ValueError("Current model does not expose a valid `num_hidden_layers` for MoE-LPR.")

    if finetuning_args.moelpr_layers_to_transform is None:
        layer_ids = list(range(num_layers))
    elif isinstance(finetuning_args.moelpr_layers_to_transform, str):
        if finetuning_args.moelpr_layers_to_transform.strip().lower() == "all":
            layer_ids = list(range(num_layers))
        else:
            layer_ids = [int(x) for x in finetuning_args.moelpr_layers_to_transform.split(",") if x.strip()]
    else:
        layer_ids = list(finetuning_args.moelpr_layers_to_transform)

    moelpr_config = MoelprConfig(
        task_type=TaskType.CAUSAL_LM,
        inference_mode=False,
        num_experts=finetuning_args.moelpr_num_experts,
        topk=finetuning_args.moelpr_top_k,
        layers_to_transform=layer_ids,
        aux_loss_coef=finetuning_args.moelpr_aux_loss_coef,
        lpr_loss_coef=finetuning_args.moelpr_lpr_loss_coef,
        stage=finetuning_args.moelpr_stage,
        moelpr_debug_mode=finetuning_args.moelpr_debug_mode,
    )
    model = get_peft_model(model, moelpr_config)

    if is_trainable and finetuning_args.moelpr_stage == 2:
        trainable_params = 0
        frozen_params = 0
        for name, param in model.named_parameters():
            if "moe_router_embedding" in name:
                param.requires_grad_(True)
                trainable_params += param.numel()
            else:
                param.requires_grad_(False)
                frozen_params += param.numel()
        logger.info_rank0(
            "[MoE-LPR] Stage 2 router-only training enabled: %d params trainable, %d params frozen.",
            trainable_params,
            frozen_params,
        )

    if is_trainable and cast_trainable_params_to_fp32:
        for param in filter(lambda p: p.requires_grad, model.parameters()):
            param.data = param.data.to(torch.float32)

    return model


def _setup_soft_moe_tuning(
    config: "PretrainedConfig",
    model: "PreTrainedModel",
    model_args: "ModelArguments",
    finetuning_args: "FinetuningArguments",
    is_trainable: bool,
    cast_trainable_params_to_fp32: bool,
) -> "PeftModel":
    if is_trainable:
        logger.info_rank0("Fine-tuning method: Soft MoE LoRA")

    if is_trainable:
        target_modules = finetuning_args.lora_target if not (len(finetuning_args.lora_target) == 1 and finetuning_args.lora_target[0] == "all") else None
        if target_modules is not None:
            target_modules = patch_target_modules(model, finetuning_args, target_modules)

        language_map = load_language_map(finetuning_args.language_map)
        language_list, family_list, language_to_family, subgroup_sizes, language_to_subgroup_ids = _build_language_metadata(
            finetuning_args.language_map
        )
        num_experts = finetuning_args.soft_moe_num_experts
        if family_list and len(family_list) != num_experts:
            raise ValueError(f"soft_moe_num_experts={num_experts} but language_map defines {len(family_list)} groups.")

        modules_to_save, trainable_token_indices = _resolve_trainable_token_setup(finetuning_args)
        peft_kwargs = {
            "r": finetuning_args.lora_rank,
            "target_modules": target_modules,
            "lora_alpha": finetuning_args.lora_alpha,
            "lora_dropout": finetuning_args.lora_dropout,
            "lora_num": 1,
            "use_hydralora_experts": True,
            "num_experts": num_experts,
            "top_k": 1,
            "soft_moe_temperature": finetuning_args.soft_moe_temperature,
            "modules_to_save": modules_to_save,
            "trainable_token_indices": trainable_token_indices,
            "language_map": language_map,
            "language_list": language_list,
            "family_list": family_list,
            "language_to_family_ids": language_to_family,
            "language_to_subgroup_ids": language_to_subgroup_ids,
            "language_column": finetuning_args.language_column,
            "language_router_mode": finetuning_args.language_router_mode,
            "language_guidance_scope": "all",
            "language_prior_weight": finetuning_args.language_prior_weight,
            "track_router_metrics": finetuning_args.track_router_metrics,
            "language_bias_value": finetuning_args.language_bias_value,
        }
        soft_moe_config = SoftMoeConfig(task_type=TaskType.CAUSAL_LM, inference_mode=False, **peft_kwargs)
        model = get_peft_model(model, soft_moe_config)

    if is_trainable and cast_trainable_params_to_fp32:
        for param in filter(lambda p: p.requires_grad, model.parameters()):
            param.data = param.data.to(torch.float32)

    return model


def _setup_grad_iso_tuning(
    config: "PretrainedConfig",
    model: "PreTrainedModel",
    model_args: "ModelArguments",
    finetuning_args: "FinetuningArguments",
    is_trainable: bool,
    cast_trainable_params_to_fp32: bool,
) -> "PeftModel":
    if is_trainable:
        logger.info_rank0("Fine-tuning method: Gradient-Isolated LoRA")

    if is_trainable:
        target_modules = finetuning_args.lora_target if not (len(finetuning_args.lora_target) == 1 and finetuning_args.lora_target[0] == "all") else None
        if target_modules is not None:
            target_modules = patch_target_modules(model, finetuning_args, target_modules)

        language_map = load_language_map(finetuning_args.language_map)
        language_list, family_list, language_to_family, subgroup_sizes, language_to_subgroup_ids = _build_language_metadata(
            finetuning_args.language_map
        )
        num_partitions = finetuning_args.grad_iso_num_partitions
        if family_list and len(family_list) != num_partitions:
            raise ValueError(f"grad_iso_num_partitions={num_partitions} but language_map defines {len(family_list)} groups.")

        modules_to_save, trainable_token_indices = _resolve_trainable_token_setup(finetuning_args)
        peft_kwargs = {
            "r": finetuning_args.lora_rank,
            "target_modules": target_modules,
            "lora_alpha": finetuning_args.lora_alpha,
            "lora_dropout": finetuning_args.lora_dropout,
            "use_hydralora_experts": False,
            "grad_iso_num_partitions": num_partitions,
            "grad_iso_inference_mode": finetuning_args.grad_iso_inference_mode,
            "modules_to_save": modules_to_save,
            "trainable_token_indices": trainable_token_indices,
            "language_map": language_map,
            "language_list": language_list,
            "family_list": family_list,
            "language_to_family_ids": language_to_family,
            "language_column": finetuning_args.language_column,
            "language_guidance_scope": "all",
            "track_router_metrics": finetuning_args.track_router_metrics,
        }
        grad_iso_config = GradIsoConfig(task_type=TaskType.CAUSAL_LM, inference_mode=False, **peft_kwargs)
        model = get_peft_model(model, grad_iso_config)

    if is_trainable and cast_trainable_params_to_fp32:
        for param in filter(lambda p: p.requires_grad, model.parameters()):
            param.data = param.data.to(torch.float32)

    return model


def _setup_lang_gate_tuning(
    config: "PretrainedConfig",
    model: "PreTrainedModel",
    model_args: "ModelArguments",
    finetuning_args: "FinetuningArguments",
    is_trainable: bool,
    cast_trainable_params_to_fp32: bool,
) -> "PeftModel":
    if is_trainable:
        logger.info_rank0("Fine-tuning method: Language-Gated LoRA")

    if is_trainable:
        target_modules = finetuning_args.lora_target if not (len(finetuning_args.lora_target) == 1 and finetuning_args.lora_target[0] == "all") else None
        if target_modules is not None:
            target_modules = patch_target_modules(model, finetuning_args, target_modules)

        language_map = load_language_map(finetuning_args.language_map)
        language_list, family_list, language_to_family, subgroup_sizes, language_to_subgroup_ids = _build_language_metadata(
            finetuning_args.language_map
        )

        modules_to_save, trainable_token_indices = _resolve_trainable_token_setup(finetuning_args)
        peft_kwargs = {
            "r": finetuning_args.lora_rank,
            "target_modules": target_modules,
            "lora_alpha": finetuning_args.lora_alpha,
            "lora_dropout": finetuning_args.lora_dropout,
            "use_hydralora_experts": False,
            "lang_gate_type": finetuning_args.lang_gate_type,
            "lang_gate_init": finetuning_args.lang_gate_init,
            "modules_to_save": modules_to_save,
            "trainable_token_indices": trainable_token_indices,
            "language_map": language_map,
            "language_list": language_list,
            "family_list": family_list,
            "language_to_family_ids": language_to_family,
            "language_column": finetuning_args.language_column,
            "language_guidance_scope": "all",
            "track_router_metrics": finetuning_args.track_router_metrics,
        }
        lang_gate_config = LangGateConfig(task_type=TaskType.CAUSAL_LM, inference_mode=False, **peft_kwargs)
        model = get_peft_model(model, lang_gate_config)

    if is_trainable and cast_trainable_params_to_fp32:
        for param in filter(lambda p: p.requires_grad, model.parameters()):
            param.data = param.data.to(torch.float32)

    return model


def init_adapter(
    config: "PretrainedConfig",
    model: "PreTrainedModel",
    model_args: "ModelArguments",
    finetuning_args: "FinetuningArguments",
    is_trainable: bool,
) -> "PreTrainedModel":
    r"""Initialize the adapters.

    Support full-parameter, freeze and LoRA training.

    Note that the trainable parameters must be cast to float32.
    """
    if is_trainable and getattr(model, "quantization_method", None) is not None:
        if finetuning_args.finetuning_type not in ["lora", "oft"]:
            raise ValueError("Quantized models can only be used for the LoRA or OFT tuning.")

        if finetuning_args.pissa_init:
            raise ValueError("Cannot initialize PiSSA adapter on quantized models.")

    # cast trainable parameters to float32 if:
    # 1. is_trainable and not pure_bf16 and not badam and quantization_bit is not None (qlora)
    # 2. is_trainable and not pure_bf16 and not badam and not zero3 (zero3 already in fp32)
    cast_trainable_params_to_fp32 = False
    if not is_trainable:
        pass
    elif finetuning_args.pure_bf16 or finetuning_args.use_badam:
        logger.info_rank0("Pure bf16 / BAdam detected, remaining trainable params in half precision.")
    elif model_args.quantization_bit is None and (is_deepspeed_zero3_enabled() or _accelerate_wants_fsdp()):
        logger.info_rank0("DeepSpeed ZeRO3 / FSDP detected, remaining trainable params in float32.")
    else:
        logger.info_rank0("Upcasting trainable params to float32.")
        cast_trainable_params_to_fp32 = True

    if finetuning_args.finetuning_type == "full":
        _setup_full_tuning(model, finetuning_args, is_trainable, cast_trainable_params_to_fp32)
    elif finetuning_args.finetuning_type == "freeze":
        _setup_freeze_tuning(model, finetuning_args, is_trainable, cast_trainable_params_to_fp32)
    elif finetuning_args.finetuning_type in ["lora", "oft"]:
        model = _setup_lora_tuning(
            config, model, model_args, finetuning_args, is_trainable, cast_trainable_params_to_fp32
        )
    elif finetuning_args.finetuning_type == "cola":
        model = _setup_cola_tuning(
            config, model, model_args, finetuning_args, is_trainable, cast_trainable_params_to_fp32
        )
    elif finetuning_args.finetuning_type == "hydralora":
        model = _setup_hydralora_tuning(
            config, model, model_args, finetuning_args, is_trainable, cast_trainable_params_to_fp32
        )
    elif finetuning_args.finetuning_type == "hala":
        model = _setup_hala_tuning(
            config, model, model_args, finetuning_args, is_trainable, cast_trainable_params_to_fp32
        )
    elif finetuning_args.finetuning_type == "adamole":
        model = _setup_adamole_tuning(
            config, model, model_args, finetuning_args, is_trainable, cast_trainable_params_to_fp32
        )
    elif finetuning_args.finetuning_type == "mixlora":
        model = _setup_mixlora_tuning(
            config, model, model_args, finetuning_args, is_trainable, cast_trainable_params_to_fp32
        )
    elif finetuning_args.finetuning_type == "moelora":
        model = _setup_moelora_tuning(
            config, model, model_args, finetuning_args, is_trainable, cast_trainable_params_to_fp32
        )
    elif finetuning_args.finetuning_type == "mtllora":
        model = _setup_mtllora_tuning(
            config, model, model_args, finetuning_args, is_trainable, cast_trainable_params_to_fp32
        )
    elif finetuning_args.finetuning_type == "movlora":
        model = _setup_movlora_tuning(
            config, model, model_args, finetuning_args, is_trainable, cast_trainable_params_to_fp32
        )
    elif finetuning_args.finetuning_type == "hmora":
        model = _setup_hmora_tuning(
            config, model, model_args, finetuning_args, is_trainable, cast_trainable_params_to_fp32
        )
    elif finetuning_args.finetuning_type == "mola":
        model = _setup_mola_tuning(
            config, model, model_args, finetuning_args, is_trainable, cast_trainable_params_to_fp32
        )
    elif finetuning_args.finetuning_type == "vanilla_moelora":
        model = _setup_vanilla_moelora_tuning(
            config, model, model_args, finetuning_args, is_trainable, cast_trainable_params_to_fp32
        )
    elif finetuning_args.finetuning_type == "moelpr":
        model = _setup_moelpr_tuning(
            config, model, model_args, finetuning_args, is_trainable, cast_trainable_params_to_fp32
        )
    elif finetuning_args.finetuning_type == "soft_moe":
        model = _setup_soft_moe_tuning(
            config, model, model_args, finetuning_args, is_trainable, cast_trainable_params_to_fp32
        )
    elif finetuning_args.finetuning_type == "grad_iso":
        model = _setup_grad_iso_tuning(
            config, model, model_args, finetuning_args, is_trainable, cast_trainable_params_to_fp32
        )
    elif finetuning_args.finetuning_type == "lang_gate":
        model = _setup_lang_gate_tuning(
            config, model, model_args, finetuning_args, is_trainable, cast_trainable_params_to_fp32
        )
    else:
        raise NotImplementedError(f"Unknown finetuning type: {finetuning_args.finetuning_type}.")

    if (
        is_trainable
        and (is_deepspeed_zero3_enabled() or _accelerate_wants_fsdp())
        and getattr(model_args, "compute_dtype", None) in (torch.float16, torch.bfloat16)
    ):
        target_dtype = model_args.compute_dtype
        if finetuning_args.finetuning_type == "moelpr":
            for name, param in model.named_parameters():
                if "moe_" in name and param.dtype != target_dtype:
                    param.data = param.data.to(target_dtype)
        for param in filter(lambda p: p.requires_grad, model.parameters()):
            if param.dtype != target_dtype:
                param.data = param.data.to(target_dtype)
        logger.info_rank0(f"FSDP/ZeRO-3 detected, casting trainable params to {target_dtype}.")

    return model
